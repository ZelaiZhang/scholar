# Interview Evidence research prototype

- Only synthetic, public, or researcher-approved deidentified research inputs. Stop on recognizable identifying health information.
- No personal diagnosis/treatment advice. Outputs concern evidence and criteria, not clinical decisions.
- No training, GPU jobs, live model calls or real-patient experiments during repository development. Unit checks and synthetic fixture replays are allowed.
- External extraction transports require explicit source-level authorization; keep default operation offline.
- Keep raw turns append-only; unknown is not negative; never treat citation validation as semantic truth.
- Preserve experiment logs, prompts, hashes, parameters and source versions. Do not invent results or novelty claims.
- Use standard-library Python, target Python >=3.11. Avoid unnecessary dependencies.
- Agents own their assigned files; coordinate interface changes before editing another agent's module.
