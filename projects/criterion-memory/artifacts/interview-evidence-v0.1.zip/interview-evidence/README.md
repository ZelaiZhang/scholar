# Interview Evidence v0.1

面向多轮问诊研究的**条件证据提取、选择与追问原型**。它是新的独立代码库，尚未接入你的原诊断树，也没有新的医学效果数据。原系统的 117/132 不属于本原型。

关注的问题是：**一条信息对应哪个诊断条件、哪个时间事件，它支持还是反驳什么，判断时必须保留哪些问答？** JSON 是输入格式；关键机制是条件关联、明确缺口、保留反证及有时间戳的修订。

## 已实现的流程

1. 根据条件定义和当前对话前缀生成提取请求。只包含可见问答和规则，排除未来回答、gold 标注、去重状态和旧模型判断。提供模型无关的传输接口，默认完全离线。
2. 接纳带原问题、原回答、字符位置及范围的候选证据。引用必须与原文逐字相符，回答必须链接到被引用的问题；失败项保留拒绝原因。
3. 维护 `supported / refuted / unknown / conflicted` 四态。没有问到、没说清楚不等于否定；其他事件的证据不覆盖当前事件；矛盾双方一起保留。
4. 人工批准同一事件的更正后，追加替代关系，保留原记录，记录相关依赖并重新计算条件。批准和接纳各有生效时间，后来的批准不会改写此前的前缀。
5. 对每个条件保留各子要素、各规则极性的最新见证，构建独立判断包。预算覆盖完整 JSON，包括规则、范围和引用；不足时不给出可发送的包。
6. 只用单独的提问记录做意图与范围去重。已回答但证据不足可以有限澄清；优先覆盖更多未解决子要素；拒答或达到上限则延后。

代码按布尔、数值比较和字符串等值规则计算证据状态，**不输出个人诊断、治疗或用药建议**。`rule_branch_eligible` 只表示程序规则已确定且包可装入预算，供研究适配器参考。

## 本机直接运行

要求 Python ≥3.11，无运行时第三方依赖。本机系统 Python 是 3.9，可使用已经存在的 3.12 环境：

```bash
cd /Users/zhitaozhang/Documents/interview-evidence
PYTHONPATH=src /Users/zhitaozhang/Documents/scholar/.venv/bin/python -m interview_evidence demo
PYTHONPATH=src /Users/zhitaozhang/Documents/scholar/.venv/bin/python -m unittest discover -s tests -v
```

其他环境也可以在已有 Python ≥3.11 下安装到自己的虚拟环境：

```bash
python -m pip install -e .
interview-evidence demo
```

合成示例使用任意教学条件 X；其中的 14 天阈值不是临床规则，未复制 SCID/DSM 书籍内容。

```bash
PYTHONPATH=src python -m interview_evidence replay examples/synthetic-interview.json --current-turn 8
PYTHONPATH=src python -m interview_evidence replay examples/synthetic-interview.json --current-turn 10
PYTHONPATH=src python -m interview_evidence replay examples/synthetic-interview.json --budget-bytes 0
PYTHONPATH=src python -m interview_evidence build-request examples/extraction-input.json --current-turn 2 --model YOUR_MODEL --output local-request.json
PYTHONPATH=src python -m interview_evidence ingest-response examples/extraction-input.json examples/extractor-response.json --current-turn 2 --output admitted-prefix.json
```

后两条只读写本地文件，不发送请求。输出文件已存在时拒绝覆盖。`ingest-response` 生成**当前前缀的新快照**，保留原输入文件；不会把原文件的未来对话、未来证据或未来批准复制进快照。继续交互时由实验器追加实际新获得的轮次。

## 接到现有模型调用器和树

入口在 [pipeline.py](src/interview_evidence/pipeline.py) 与 [extraction.py](src/interview_evidence/extraction.py)。不绑定特定服务商，不读取 API key。实验仓库可以将已有模型调用器包装成：

```python
from interview_evidence.extraction import TransportReply, extract_with_transport

def existing_model_transport(request):
    # 在你自己的实验仓库实现，并记录服务端实际返回的 token 使用量。
    # request.messages 是唯一应传入模型的对话；不要附加 gold/完整病例。
    response = your_existing_client(request.messages, request.model, request.parameters)
    return TransportReply(response.text, response.input_tokens, response.output_tokens,
                          response.request_id)

# 仅当该来源 data_policy.external_api_allowed 明确为 true 时才可调用。
updated_prefix, receipt = extract_with_transport(
    research_document, existing_model_transport, model="你的冻结模型版本",
    current_turn=current_turn, parameters={"temperature": 0}
)
```

这个示例依赖你已有的 `your_existing_client`，本库不提供或调用它。未得到来源授权时，函数在传输调用前拒绝。失败响应抛出 `ExtractionFailure`，其 `receipt` 保留已知调用成本，不应在实验汇总时丢弃失败。

树节点需要映射到 `CriterionSpec`；时间范围、阈值和排除规则须由研究者审核。模型提议值及时间范围仍需要语义评测。判断器只接收 `evidence_packets[node_id].payload`，不能附加提问记录或旧预测。包不可行、状态未知或冲突时如何延后由外部树适配器决定。本原型没有原树遍历、路径回退或最终疾病复判。

获批更正使用单独的 `submit_approved_revision(document, proposal, approval_turn=...)`，并明确指出被替代的账本 ID。不要把此函数作为提取模型可以自行调用的工具。普通提取请求不带旧证据 ID，要求 `supersedes=[]`；模型不会自动批准、更改旧证据。

## 对“真正关键信息”的保证边界

- **逐字引用正确不等于语义正确。** 模型可能对同一个真实回答提议相反的值。测试明确演示这一限制；需要独立 gold 标注评价极性、数值和事件范围。
- 见证选择保持的是相对于已接纳账本及当前简单规则的状态，不保证源对话抽取完整，也不保证保留同规则侧的所有数值差异、限定词或不确定原因。不是全局最小或最优压缩。
- 提问分数是未解决子要素覆盖数，未估计诊断熵或临床信息增益。当前会覆盖整体条件已由逻辑短路确定时的剩余未知项，停止规则需要外部研究协议。
- 默认预算是 **UTF-8 字节**，不是 token。调用 `pack_evidence(..., cost_fn=精确分词计数, cost_unit="tokens")` 才能使用 tokenizer 预算；实际全链路费用还包括提取、判断和失败重试。
- 回放输出的零调用仅描述本次本地程序；已有提取成本在 `extraction_provenance`。空 token 字段表示未知，不表示免费。
- 标识信息检测只是保守的停止提示，不是脱敏保证。只输入合法公开、合成或已批准的脱敏研究资料；发现疑似可识别健康信息停止处理。

## 如何做论文实验

首先冻结对话前缀、知识和 gold，分别比较提取器与选择器，再评价完整管线。强对照应包括完整轮次 JSON、完整信息单轮整合、任务摘要、条件相关检索，以及相同预算的普通额外复算。正确候选保留和错误候选排除分开报告；保存错→对和对→错，不只报净增。

详细方法和设计保存在 `scholar/projects/criterion-memory`，与执行仓库分离。候选题目：**《诊断准则约束下的关键信息保持：面向多轮问诊的可追溯证据选择与修订》**。这仍是待验证研究问题，是否形成论文主贡献由真实实验和最近工作对照决定。

## 文件入口

| 文件 | 用途 |
|---|---|
| `models.py / ledger.py / reasoning.py` | 严格数据类型、来源锚定、四态规则、修订和历史可见性 |
| `packing.py / planning.py` | 判断证据包与独立追问规划 |
| `pipeline.py / extraction.py` | 前缀回放、提取请求、来源授权、接纳与成本追溯 |
| `examples/` | 合成对话、无标注提取输入和本地响应示例 |
| `tests/` | 软件行为检查；不构成医疗效果实验 |
| `docs/IMPLEMENTATION-CONTRACT.md` | 模块接口与边界 |
