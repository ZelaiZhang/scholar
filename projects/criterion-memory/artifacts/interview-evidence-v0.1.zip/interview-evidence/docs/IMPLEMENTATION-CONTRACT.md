# Implementation contract v0.1

The repository is a new standalone research prototype, not the researcher's existing tree system. Frozen synthetic fixtures test software behavior, not medical effectiveness. Root owns packaging, CLI, extraction interface, orchestration, examples and documentation. Core agent owns models.py, ledger.py, reasoning.py and their tests. Selection agent owns packing.py, planning.py and their tests. Scientific agent owns only new scholar design/method documents.

## Models (immutable dataclasses, plain strings for enums)

- Span(turn_id: int, start: int, end: int, quote: str). Offsets are Python Unicode code-point offsets, half-open.
- Turn(id: int, role: str, text: str, reply_to: int | None = None). Roles are assistant or user. A user answer links to its assistant question via reply_to. IDs are positive and append in ascending order.
- FacetSpec(id: str, kind: str, operator: str, target: bool | int | float | str, scope_id: str, question: str, intent_id: str). kind is boolean, number or string. Operators equals, gte and lte (numeric only for inequalities).
- CriterionSpec(id: str, label: str, facets: tuple[FacetSpec, ...], logic: str = 'all', threshold: int | None = None, depends_on: tuple[str, ...] = ()). Logic all, any or at_least. depends_on declares invalidation dependencies, NOT a clinical Boolean prerequisite. Explicit Boolean composition is via facets.
- EvidenceClaim(id: str, criterion_id: str, facet_id: str, value: bool | int | float | str | None, scope_id: str, question: Span, answer: Span, supersedes: tuple[str, ...] = (), origin: str = 'external_proposal'). None is insufficient information, never false.
- FacetState(facet_id: str, scope_id: str, status: str, evidence_ids: tuple[str, ...]). States supported, refuted, unknown, conflicted.
- CriterionState(criterion_id: str, status: str, facets: tuple[FacetState, ...], evidence_ids: tuple[str, ...], missing_facet_ids: tuple[str, ...]). Status has the same four values. Missing includes unresolved facets (unknown/conflicted).
- ValidationError(ValueError).
- parse_turn(mapping), parse_criterion(mapping), parse_claim(mapping): strict JSON validation including bool-vs-int distinctions, finite numeric values and unknown keys. to_dict(value) recursively serializes dataclasses.
- validate_knowledge(criteria) checks unique IDs, nonempty facets, valid targets, thresholds, dependency existence and cycles.

## Ledger and reasoning

- EvidenceLedger(criteria: Iterable[CriterionSpec]); attributes criteria: dict[str, CriterionSpec], turns: dict[int, Turn], claims: dict[str, EvidenceClaim].
- add_turn(turn) and add_claim(claim, *, current_turn: int, approve_revision: bool = False). Validate both exact quotes, answer/question role/link, source visibility, known criterion/facet and type. Revisions require explicit approval, must target older active claims for the SAME criterion/facet/scope; cross-time revisions rejected. Never delete source records. Duplicate IDs rejected. Validate before mutation.
- active_claims(*, criterion_id: str | None = None, facet_id: str | None = None, scope_id: str | None = None, current_turn: int | None = None) returns tuple in deterministic order. Historical prefixes must not see future supersession. all original claims stay in claims.
- evaluate_criterion(criterion: CriterionSpec, claims: Iterable[EvidenceClaim]) -> CriterionState. Compute evidence relation by validated value vs facet rule. Opposing values within the same scope are conflicted; matching values in other periods ignored. Missing/None unknown. No self-reported confidence threshold. Criterion aggregation preserves uncertainty; refutation may decisively refute all, support may decisively support any. For threshold rules use conservative supported/possible count bounds.
- evaluate_all(ledger, *, current_turn: int) -> dict[str, CriterionState].
- affected_criteria(criteria, changed_ids) -> tuple[str, ...], including transitive dependents in stable order. This supports invalidating derived caches, not inventing a diagnosis.

## Evidence packing (selection agent)

- EvidencePacket(payload: dict | None, selected_ids: tuple[str, ...], omitted_ids: tuple[str, ...], feasible: bool, cost: int, cost_unit: str, reason: str, input_sha256: str | None).
- pack_evidence(criterion: CriterionSpec, ledger: EvidenceLedger, *, current_turn: int, budget: int, cost_fn: Callable[[str], int] | None = None, cost_unit: str = 'utf8_bytes') -> EvidencePacket.
- Canonical JSON cost covers the whole judge payload (current criterion, rule definitions, selected question/answer quotes and scope). Default budget is BYTES, not tokens. Inject an exact model tokenizer to use token budgets. No question history, dedup flag or old model decision enters payload.
- Pick deterministic witnesses per facet, retaining both sides for conflict. Required evidence is atomic; never keep only one side and silently change conflicted to supported. Use at least all resolved facets' witness sets for initial version; optional extra claims may be omitted, but their omission is explicit. Unknown facets remain visible as coverage gaps. If required envelope doesn't fit, payload=None and feasible=False; never send oversized content or claim budget=0 context is sufficient.
- Query the ledger at current_turn to prevent future evidence or future revisions from influencing a packet. Evidence selection does not depend on question ledger.

## Question planning (selection agent)

- QuestionRecord(intent_id: str, scope_id: str, turn_id: int, status: str, clarification_count: int = 0). status asked, answered, declined. A record tracks delivered questions; it never changes evidence state.
- QuestionPlan(action: str, intent_id: str | None, scope_id: str | None, question: str | None, criterion_ids: tuple[str, ...], facet_ids: tuple[str, ...], reason: str, score: int). action ask, clarify, defer or none.
- plan_question(criteria: Iterable[CriterionSpec], states: Mapping[str, CriterionState], history: Iterable[QuestionRecord], *, current_turn: int, max_clarifications: int = 2) -> QuestionPlan.
- Group unresolved facets by explicit intent_id + scope_id; prioritize unresolved coverage across criteria, then conflicts; stable ties. Describe score as a deterministic coverage heuristic, NOT estimated clinical information gain. Asked/answered with missing evidence allows bounded clarification. Declined or limit reached defers. Different event scopes do not deduplicate. No mutation of criteria/states/history. Validate future history and invalid limits.

## Integration owned by root

JSON document: schema_version=1, data_policy={source_id, origin:synthetic|public|deidentified, external_api_allowed:boolean}, knowledge_version, turns, criteria, claims, approved_revision_ids, question_history. Optional claim_acceptance_turns records delayed admission; default is the annotated answer turn. revision_approval_turns is required for every approved revision; its effective admission time is max(acceptance, approval). Optional extraction_runs preserves separate model-cost receipts. Fixture annotations and expected values NEVER enter extraction requests. A provider-neutral transport may be injected with an explicit source gate; no SDK or network is required by default. Extraction prompts request only current-prefix anchored proposals; revision approval cannot be granted by a model response. Normal extraction forbids supersedes; explicit submit_approved_revision is a separate researcher workflow. Admission namespaces temporary IDs using visible-prefix context and returns a new prefix-only snapshot, preserving caller input and excluding future metadata.

Pipeline returns criterion evidence states, packets, question plan, structurally rejected claims, dependency invalidation records and provenance. No patient diagnosis label. CLI demo and local replay use synthetic fixtures only. Tests exercise paraphrase/quote grounding, negative/unknown distinction, time scopes, revision closure, budget safety and dedup-input invariance. They are software checks, not experimental effect sizes.
