"""Offline research prototype; evidence states are not patient diagnoses."""

__version__ = "0.1.0"
