"""Offline CLI: no model or network commands."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .demo import synthetic_document
from .extraction import build_request, ingest_response
from .io import read_json, write_new_json
from .models import ValidationError, to_dict
from .pipeline import parse_document, resolve_prefix, run_pipeline


def _emit(value: object, path: str | None) -> None:
    if path:
        write_new_json(path, value)
        print(path)
    else:
        print(json.dumps(to_dict(value), ensure_ascii=False, indent=2, allow_nan=False))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Offline criterion-evidence research prototype (Python >=3.11)")
    sub = parser.add_subparsers(dest="command", required=True)
    demo = sub.add_parser("demo", help="replay a wholly synthetic, nonclinical fixture")
    demo.add_argument("--budget-bytes", type=int, default=8192)
    demo.add_argument("--output")
    replay = sub.add_parser("replay", help="validate and replay a source-declared local research document")
    replay.add_argument("document")
    replay.add_argument("--current-turn", type=int)
    replay.add_argument("--budget-bytes", type=int, default=8192)
    replay.add_argument("--max-clarifications", type=int, default=2)
    replay.add_argument("--output")
    request = sub.add_parser("build-request", help="save a local request; this command sends nothing")
    request.add_argument("document")
    request.add_argument("--current-turn", type=int)
    request.add_argument("--model", required=True)
    request.add_argument("--output")
    ingest = sub.add_parser("ingest-response", help="validate a local extractor response into a NEW document")
    ingest.add_argument("document")
    ingest.add_argument("response")
    ingest.add_argument("--current-turn", type=int)
    ingest.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "demo":
            value = synthetic_document()
            results = []
            for cutoff in (0, 8, 10, 12, 14):
                report = run_pipeline(value, current_turn=cutoff, budget_bytes=args.budget_bytes)
                results.append({"current_turn": cutoff,
                                "criterion_states": report["criterion_states"],
                                "question_plan": report["question_plan"],
                                "rule_branch_eligible": report["rule_branch_eligible"],
                                "rejected_claims": report["rejected_claims"],
                                "packet_cost_bytes": {key: item["cost"] for key, item in report["evidence_packets"].items()}})
            _emit({"fixture": "synthetic, nonclinical toy X", "prefixes": results}, args.output)
        elif args.command == "replay":
            _emit(run_pipeline(read_json(args.document), current_turn=args.current_turn,
                               budget_bytes=args.budget_bytes, max_clarifications=args.max_clarifications), args.output)
        elif args.command == "build-request":
            _emit(build_request(read_json(args.document), current_turn=args.current_turn,
                                model=args.model), args.output)
        else:
            value = read_json(args.document)
            cutoff = resolve_prefix(parse_document(value), args.current_turn)
            response_path = Path(args.response)
            if response_path.stat().st_size > 10 * 1024 * 1024:
                raise ValidationError("extractor response exceeds the 10 MiB limit")
            updated, report = ingest_response(value, response_path.read_text(encoding="utf-8"), current_turn=cutoff)
            write_new_json(args.output, updated)
            _emit({"output": args.output, "admission_report": report}, None)
    except (ValidationError, OSError, UnicodeError) as exc:
        print("input rejected: " + str(exc), file=sys.stderr)
        return 2
    return 0
