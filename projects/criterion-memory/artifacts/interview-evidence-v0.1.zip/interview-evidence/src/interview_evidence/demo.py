"""Fully synthetic, nonclinical conditions; no SCID/DSM text or patient records."""

from __future__ import annotations

from .models import CriterionSpec, EvidenceClaim, FacetSpec, Span, Turn, to_dict


def synthetic_document() -> dict:
    """An arbitrary toy condition X; threshold 14 is not a diagnostic rule."""
    current, past = "episode:current", "episode:past"
    present = FacetSpec("present", "boolean", "equals", True, current,
                        "当前事件中，示例表现 X 是否出现？", "presence")
    duration = FacetSpec("duration", "number", "gte", 14, current,
                         "当前事件中的示例表现 X 持续了多少天？", "duration")
    impact = FacetSpec("impact", "boolean", "equals", True, current,
                       "当前事件中的示例表现 X 是否影响了示例活动？", "impact")
    past_present = FacetSpec("present", "boolean", "equals", True, past,
                            "过去事件中，示例表现 X 是否出现？", "presence")
    criteria = (
        CriterionSpec("current", "非临床示例：当前 X 且时长达到任意教学阈值", (present, duration)),
        CriterionSpec("past", "非临床示例：过去事件的 X", (past_present,)),
        CriterionSpec("impact", "非临床示例：当前活动影响", (impact,), depends_on=("current",)),
        CriterionSpec("combined", "非临床示例：时长与活动影响", (duration, impact),
                      depends_on=("impact",)),
    )
    texts = (
        ("assistant", present.question, None), ("user", "当前有示例表现 X。", 1),
        ("assistant", duration.question, None), ("user", "当前持续了 21 天。", 3),
        ("assistant", past_present.question, None), ("user", "过去的事件也出现过 X。", 5),
        ("assistant", impact.question, None), ("user", "我不确定有没有影响示例活动。", 7),
        ("assistant", "请核对当前事件的时长，前面说的 21 天是否准确？", None),
        ("user", "我更正前面的回答：当前事件只有 3 天，21 天说错了。", 9),
        ("assistant", "请再次描述当前事件中是否出现 X。", None),
        ("user", "当前没有出现 X。", 11),
        ("assistant", "前后关于当前 X 的回答不同，哪一条需要更正？", None),
        ("user", "更正当前有 X 的回答：当前没有 X，刚才的否认是准确的。", 13),
    )
    turns = tuple(Turn(i, *item) for i, item in enumerate(texts, 1))
    by_id = {turn.id: turn for turn in turns}

    def claim(identifier: str, criterion: str, facet: str, value: object,
              answer_id: int, scope: str = current, supersedes: tuple[str, ...] = ()) -> EvidenceClaim:
        answer = by_id[answer_id]
        question = by_id[answer.reply_to]
        return EvidenceClaim(identifier, criterion, facet, value, scope,
                             Span(question.id, 0, len(question.text), question.text),
                             Span(answer.id, 0, len(answer.text), answer.text),
                             supersedes, "synthetic_annotation")

    claims = (
        claim("current-present-v1", "current", "present", True, 2),
        claim("current-duration-v1", "current", "duration", 21, 4),
        claim("combined-duration-v1", "combined", "duration", 21, 4),
        claim("past-present-v1", "past", "present", True, 6, past),
        claim("current-offscope", "current", "present", False, 6, past),
        claim("impact-insufficient", "impact", "impact", None, 8),
        claim("combined-impact-insufficient", "combined", "impact", None, 8),
        claim("current-duration-v2", "current", "duration", 3, 10,
              supersedes=("current-duration-v1",)),
        claim("combined-duration-v2", "combined", "duration", 3, 10,
              supersedes=("combined-duration-v1",)),
        claim("current-present-v2", "current", "present", False, 12),
        claim("current-present-v3", "current", "present", False, 14,
              supersedes=("current-present-v1", "current-present-v2")),
    )
    approved = [claim.id for claim in claims if claim.supersedes]
    return {
        "schema_version": 1,
        "data_policy": {"source_id": "synthetic:toy-X-v1", "origin": "synthetic", "external_api_allowed": False},
        "knowledge_version": "toy-X-not-clinical-v1",
        "turns": to_dict(turns), "criteria": to_dict(criteria), "claims": to_dict(claims),
        "approved_revision_ids": approved,
        "revision_approval_turns": {claim.id: claim.answer.turn_id for claim in claims if claim.supersedes},
        "claim_acceptance_turns": {claim.id: claim.answer.turn_id for claim in claims},
        "question_history": [
            {"intent_id": "presence", "scope_id": current, "turn_id": 2, "status": "answered"},
            {"intent_id": "duration", "scope_id": current, "turn_id": 4, "status": "answered"},
            {"intent_id": "presence", "scope_id": past, "turn_id": 6, "status": "answered"},
            {"intent_id": "impact", "scope_id": current, "turn_id": 8, "status": "answered"},
        ],
    }


def empty_extraction_document() -> dict:
    value = synthetic_document()
    value["claims"] = []
    value["approved_revision_ids"] = []
    value["revision_approval_turns"] = {}
    value["claim_acceptance_turns"] = {}
    return value
