"""Strict local JSON I/O. Generated files never overwrite existing material."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

from .models import ValidationError, to_dict


def canonical_json(value: Any) -> str:
    return json.dumps(to_dict(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValidationError("duplicate JSON key")
        result[key] = value
    return result


def loads_json(text: str) -> Any:
    def reject_constant(value: str) -> None:
        raise ValidationError("non-finite JSON constant: " + value)
    def finite_float(value: str) -> float:
        result = float(value)
        if not math.isfinite(result):
            raise ValidationError("JSON numeric overflow")
        return result
    try:
        result = json.loads(text, object_pairs_hook=_unique_object,
                            parse_constant=reject_constant, parse_float=finite_float)
        validate_json_value(result)
        return result
    except ValidationError:
        raise
    except (ValueError, TypeError, OverflowError, RecursionError) as exc:
        raise ValidationError("invalid JSON") from exc


def validate_json_value(value: Any) -> None:
    """Reject coercions that Python's JSON serializer would silently perform."""
    if type(value) is dict:
        if any(type(key) is not str for key in value):
            raise ValidationError("JSON object keys must be strings")
        for key, item in value.items():
            validate_json_value(key)
            validate_json_value(item)
    elif type(value) is list:
        for item in value:
            validate_json_value(item)
    elif type(value) is float:
        if not math.isfinite(value):
            raise ValidationError("JSON numbers must be finite")
    elif type(value) is str:
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise ValidationError("JSON strings must be valid UTF-8 encodable Unicode") from exc
    elif value is not None and type(value) not in (str, int, bool):
        raise ValidationError("value must be strict JSON data")


def read_json(path: str | Path) -> Any:
    path = Path(path)
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValidationError("input exceeds the 10 MiB local-document limit")
    return loads_json(path.read_text(encoding="utf-8"))


def write_new_json(path: str | Path, value: Any) -> None:
    serialized = json.dumps(to_dict(value), ensure_ascii=False, indent=2,
                            allow_nan=False) + "\n"
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(serialized)
