"""Append-only, grounded evidence with prefix-safe approved revisions."""

from __future__ import annotations

from collections.abc import Iterable

from .models import (
    CriterionSpec,
    EvidenceClaim,
    Span,
    Turn,
    ValidationError,
    validate_knowledge,
    validate_value,
)


def validate_cutoff(current_turn: int) -> None:
    if type(current_turn) is not int or current_turn < 0:
        raise ValidationError("current_turn must be a nonnegative integer; bool is not an integer")


class EvidenceLedger:
    """All writes go through validation; public dictionaries are snapshots.

    Acceptance time matters separately from source time. An annotation accepted
    at turn 8 cannot silently appear in replay at turn 4 just because it quotes
    turn 4. An approved correction similarly supersedes an older claim only in
    prefixes where the correction itself was accepted.
    """

    def __init__(self, criteria: Iterable[CriterionSpec]):
        records = tuple(criteria)
        validate_knowledge(records)
        self._criteria = {criterion.id: criterion for criterion in records}
        self._turns: dict[int, Turn] = {}
        self._claims: dict[str, EvidenceClaim] = {}
        self._accepted_at: dict[str, int] = {}

    @property
    def criteria(self) -> dict[str, CriterionSpec]:
        return self._criteria.copy()

    @property
    def turns(self) -> dict[int, Turn]:
        return self._turns.copy()

    @property
    def claims(self) -> dict[str, EvidenceClaim]:
        return self._claims.copy()

    def add_turn(self, turn: Turn) -> None:
        if type(turn) is not Turn:
            raise ValidationError("add_turn requires a Turn record")
        if turn.id in self._turns:
            raise ValidationError(f"duplicate turn ID {turn.id}")
        if self._turns and turn.id <= max(self._turns):
            raise ValidationError("turn IDs must append in ascending order")
        if turn.reply_to is not None:
            question = self._turns.get(turn.reply_to)
            if question is None or question.role != "assistant":
                raise ValidationError("user reply_to must refer to an existing assistant question")
        self._turns[turn.id] = turn

    def _validate_span(self, span: Span, *, current_turn: int, role: str) -> Turn:
        turn = self._turns.get(span.turn_id)
        if turn is None:
            raise ValidationError(f"span references nonexistent turn {span.turn_id}")
        if turn.id > current_turn:
            raise ValidationError("span references a future turn outside the visible prefix")
        if turn.role != role:
            raise ValidationError(f"span must quote an {role} turn")
        if span.end > len(turn.text) or turn.text[span.start:span.end] != span.quote:
            raise ValidationError("span quote does not exactly match Unicode source offsets")
        return turn

    def add_claim(self, claim: EvidenceClaim, *, current_turn: int, approve_revision: bool = False) -> None:
        if type(claim) is not EvidenceClaim:
            raise ValidationError("add_claim requires an EvidenceClaim record")
        validate_cutoff(current_turn)
        if current_turn not in self._turns:
            raise ValidationError("claim acceptance requires an actual stored current turn")
        if self._accepted_at and current_turn < max(self._accepted_at.values()):
            raise ValidationError("claim acceptance cutoffs must append in nondecreasing order")
        if type(approve_revision) is not bool:
            raise ValidationError("approve_revision must be a boolean supplied by the caller")
        if claim.id in self._claims:
            raise ValidationError(f"duplicate claim ID {claim.id!r}")
        criterion = self._criteria.get(claim.criterion_id)
        if criterion is None:
            raise ValidationError(f"unknown criterion {claim.criterion_id!r}")
        facet = next((item for item in criterion.facets if item.id == claim.facet_id), None)
        if facet is None:
            raise ValidationError(f"unknown facet {claim.facet_id!r} in criterion {criterion.id!r}")
        validate_value(claim.value, facet.kind, allow_none=True, name="claim.value")
        question = self._validate_span(claim.question, current_turn=current_turn, role="assistant")
        answer = self._validate_span(claim.answer, current_turn=current_turn, role="user")
        if question.id >= answer.id or answer.reply_to != question.id:
            raise ValidationError("claim answer must reply directly to its quoted earlier question")
        if claim.supersedes:
            if not approve_revision:
                raise ValidationError("revision requires explicit caller approval")
            active_ids = {item.id for item in self.active_claims(current_turn=current_turn)}
            for identifier in claim.supersedes:
                target = self._claims.get(identifier)
                if target is None or identifier not in active_ids:
                    raise ValidationError("revision targets must be existing active claims in this prefix")
                if (target.criterion_id, target.facet_id, target.scope_id) != (
                    claim.criterion_id, claim.facet_id, claim.scope_id
                ):
                    raise ValidationError("revision must retain the target criterion, facet and event scope")
                if target.answer.turn_id >= answer.id:
                    raise ValidationError("revision requires a strictly later answer than every target")
        # Every validation completes before any store changes.
        self._claims[claim.id] = claim
        self._accepted_at[claim.id] = current_turn

    def active_claims(
        self,
        *,
        criterion_id: str | None = None,
        facet_id: str | None = None,
        scope_id: str | None = None,
        current_turn: int | None = None,
    ) -> tuple[EvidenceClaim, ...]:
        for name, value in (("criterion_id", criterion_id), ("facet_id", facet_id), ("scope_id", scope_id)):
            if value is not None and (type(value) is not str or not value.strip()):
                raise ValidationError(f"{name} filter must be a nonempty string or null")
        if current_turn is not None:
            validate_cutoff(current_turn)
        cutoff = max(self._turns, default=0) if current_turn is None else current_turn
        visible = tuple(
            claim for claim in self._claims.values()
            if self._accepted_at[claim.id] <= cutoff
            and claim.question.turn_id <= cutoff and claim.answer.turn_id <= cutoff
        )
        superseded = {identifier for claim in visible for identifier in claim.supersedes}
        # Apply filters after global revision closure. A scope filter cannot
        # accidentally revive an already superseded source claim.
        return tuple(
            claim for claim in visible
            if claim.id not in superseded
            and (criterion_id is None or claim.criterion_id == criterion_id)
            and (facet_id is None or claim.facet_id == facet_id)
            and (scope_id is None or claim.scope_id == scope_id)
        )
