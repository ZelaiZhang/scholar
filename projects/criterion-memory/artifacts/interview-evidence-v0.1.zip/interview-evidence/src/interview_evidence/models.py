"""Immutable, strictly validated research evidence records.

Span offsets refer to Python Unicode code points, not UTF-8 bytes. Validation
establishes structural consistency only; it does not establish clinical truth.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, fields, is_dataclass
import math
from typing import Any


class ValidationError(ValueError):
    """A record violates the documented input contract."""


STATUSES = frozenset({"supported", "refuted", "unknown", "conflicted"})


def _text(value: Any, name: str, *, nonempty: bool = True) -> None:
    if type(value) is not str or (nonempty and not value.strip()):
        raise ValidationError(f"{name} must be {'a nonempty' if nonempty else 'a'} string")


def _integer(value: Any, name: str, *, minimum: int = 0) -> None:
    if type(value) is not int or value < minimum:
        raise ValidationError(f"{name} must be an integer >= {minimum}; bool is not an integer")


def validate_value(value: Any, kind: str, *, allow_none: bool = False, name: str = "value") -> None:
    """Validate a typed facet value without bool/int coercion."""
    if value is None and allow_none:
        return
    valid = (
        (kind == "boolean" and type(value) is bool)
        or (kind == "string" and type(value) is str)
        or (kind == "number" and type(value) in (int, float))
    )
    if not valid:
        raise ValidationError(f"{name} must match facet kind {kind!r}")
    if type(value) is float and not math.isfinite(value):
        raise ValidationError(f"{name} must be finite")


def _ids(value: Any, name: str) -> None:
    if type(value) is not tuple:
        raise ValidationError(f"{name} must be an immutable tuple")
    for item in value:
        _text(item, name)
    if len(value) != len(set(value)):
        raise ValidationError(f"{name} contains duplicate identifiers")


@dataclass(frozen=True, slots=True)
class Span:
    turn_id: int
    start: int
    end: int
    quote: str

    def __post_init__(self) -> None:
        _integer(self.turn_id, "span.turn_id", minimum=1)
        _integer(self.start, "span.start")
        _integer(self.end, "span.end", minimum=1)
        _text(self.quote, "span.quote")
        if self.end <= self.start or len(self.quote) != self.end - self.start:
            raise ValidationError("span must be a nonempty half-open Unicode range matching quote length")


@dataclass(frozen=True, slots=True)
class Turn:
    id: int
    role: str
    text: str
    reply_to: int | None = None

    def __post_init__(self) -> None:
        _integer(self.id, "turn.id", minimum=1)
        if type(self.role) is not str or self.role not in {"assistant", "user"}:
            raise ValidationError("turn.role must be assistant or user")
        _text(self.text, "turn.text", nonempty=False)
        if self.reply_to is not None:
            _integer(self.reply_to, "turn.reply_to", minimum=1)
            if self.reply_to >= self.id:
                raise ValidationError("turn.reply_to must refer to an earlier turn")
            if self.role != "user":
                raise ValidationError("only user answer turns may have reply_to")


@dataclass(frozen=True, slots=True)
class FacetSpec:
    id: str
    kind: str
    operator: str
    target: bool | int | float | str
    scope_id: str
    question: str
    intent_id: str

    def __post_init__(self) -> None:
        for name in ("id", "scope_id", "question", "intent_id"):
            _text(getattr(self, name), f"facet.{name}")
        if type(self.kind) is not str or self.kind not in {"boolean", "number", "string"}:
            raise ValidationError("facet.kind must be boolean, number or string")
        if type(self.operator) is not str or self.operator not in {"equals", "gte", "lte"}:
            raise ValidationError("facet.operator must be equals, gte or lte")
        if self.operator in {"gte", "lte"} and self.kind != "number":
            raise ValidationError("inequality operators require a numeric facet")
        validate_value(self.target, self.kind, name="facet.target")


@dataclass(frozen=True, slots=True)
class CriterionSpec:
    id: str
    label: str
    facets: tuple[FacetSpec, ...]
    logic: str = "all"
    threshold: int | None = None
    depends_on: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _text(self.id, "criterion.id")
        _text(self.label, "criterion.label")
        if type(self.facets) is not tuple or not self.facets or any(type(f) is not FacetSpec for f in self.facets):
            raise ValidationError("criterion.facets must be a nonempty immutable tuple of FacetSpec")
        facet_ids = [facet.id for facet in self.facets]
        if len(set(facet_ids)) != len(facet_ids):
            raise ValidationError("criterion contains duplicate facet identifiers")
        if type(self.logic) is not str or self.logic not in {"all", "any", "at_least"}:
            raise ValidationError("criterion.logic must be all, any or at_least")
        if self.logic == "at_least":
            _integer(self.threshold, "criterion.threshold", minimum=1)
            if self.threshold > len(self.facets):
                raise ValidationError("criterion.threshold exceeds facet count")
        elif self.threshold is not None:
            raise ValidationError("criterion.threshold is only allowed for at_least")
        _ids(self.depends_on, "criterion.depends_on")


@dataclass(frozen=True, slots=True)
class EvidenceClaim:
    id: str
    criterion_id: str
    facet_id: str
    value: bool | int | float | str | None
    scope_id: str
    question: Span
    answer: Span
    supersedes: tuple[str, ...] = ()
    origin: str = "external_proposal"

    def __post_init__(self) -> None:
        for name in ("id", "criterion_id", "facet_id", "scope_id", "origin"):
            _text(getattr(self, name), f"claim.{name}")
        if self.value is not None and type(self.value) not in (bool, int, float, str):
            raise ValidationError("claim.value must be a JSON scalar or null")
        if type(self.value) is float and not math.isfinite(self.value):
            raise ValidationError("claim.value must be finite")
        if type(self.question) is not Span or type(self.answer) is not Span:
            raise ValidationError("claim question and answer must be Span records")
        _ids(self.supersedes, "claim.supersedes")
        if self.id in self.supersedes:
            raise ValidationError("a claim cannot supersede itself")


@dataclass(frozen=True, slots=True)
class FacetState:
    facet_id: str
    scope_id: str
    status: str
    evidence_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        _text(self.facet_id, "facet_state.facet_id")
        _text(self.scope_id, "facet_state.scope_id")
        if type(self.status) is not str or self.status not in STATUSES:
            raise ValidationError("invalid facet state status")
        _ids(self.evidence_ids, "facet_state.evidence_ids")


@dataclass(frozen=True, slots=True)
class CriterionState:
    criterion_id: str
    status: str
    facets: tuple[FacetState, ...]
    evidence_ids: tuple[str, ...]
    missing_facet_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        _text(self.criterion_id, "criterion_state.criterion_id")
        if type(self.status) is not str or self.status not in STATUSES:
            raise ValidationError("invalid criterion state status")
        if type(self.facets) is not tuple or any(type(f) is not FacetState for f in self.facets):
            raise ValidationError("criterion state facets must be immutable FacetState records")
        facet_ids = [f.facet_id for f in self.facets]
        if len(set(facet_ids)) != len(facet_ids):
            raise ValidationError("criterion state contains duplicate facets")
        _ids(self.evidence_ids, "criterion_state.evidence_ids")
        _ids(self.missing_facet_ids, "criterion_state.missing_facet_ids")
        unresolved = tuple(f.facet_id for f in self.facets if f.status in {"unknown", "conflicted"})
        if self.missing_facet_ids != unresolved:
            raise ValidationError("missing facet IDs must match unresolved facets in their declared order")


def _object(value: Any, allowed: set[str], required: set[str], name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationError(f"{name} must be a JSON object")
    if any(type(key) is not str for key in value):
        raise ValidationError(f"{name} keys must be strings")
    unknown = set(value) - allowed
    missing = required - set(value)
    if unknown:
        raise ValidationError(f"{name} has unknown keys: {', '.join(sorted(unknown))}")
    if missing:
        raise ValidationError(f"{name} is missing keys: {', '.join(sorted(missing))}")
    return value


def _array(value: Any, name: str) -> list[Any]:
    if type(value) is not list:
        raise ValidationError(f"{name} must be a JSON array")
    return value


def _parse_span(value: Any) -> Span:
    obj = _object(value, {"turn_id", "start", "end", "quote"}, {"turn_id", "start", "end", "quote"}, "span")
    return Span(**obj)


def parse_turn(mapping: Mapping[str, Any]) -> Turn:
    obj = _object(mapping, {"id", "role", "text", "reply_to"}, {"id", "role", "text"}, "turn")
    return Turn(**obj)


def _parse_facet(value: Any) -> FacetSpec:
    names = {"id", "kind", "operator", "target", "scope_id", "question", "intent_id"}
    return FacetSpec(**_object(value, names, names, "facet"))


def parse_criterion(mapping: Mapping[str, Any]) -> CriterionSpec:
    names = {"id", "label", "facets", "logic", "threshold", "depends_on"}
    obj = dict(_object(mapping, names, {"id", "label", "facets"}, "criterion"))
    obj["facets"] = tuple(_parse_facet(item) for item in _array(obj["facets"], "criterion.facets"))
    if "depends_on" in obj:
        obj["depends_on"] = tuple(_array(obj["depends_on"], "criterion.depends_on"))
    return CriterionSpec(**obj)


def parse_claim(mapping: Mapping[str, Any]) -> EvidenceClaim:
    names = {"id", "criterion_id", "facet_id", "value", "scope_id", "question", "answer", "supersedes", "origin"}
    obj = dict(_object(mapping, names, {"id", "criterion_id", "facet_id", "value", "scope_id", "question", "answer"}, "claim"))
    obj["question"] = _parse_span(obj["question"])
    obj["answer"] = _parse_span(obj["answer"])
    if "supersedes" in obj:
        obj["supersedes"] = tuple(_array(obj["supersedes"], "claim.supersedes"))
    return EvidenceClaim(**obj)


def to_dict(value: Any) -> Any:
    """Recursively produce JSON-compatible values from immutable records."""
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: to_dict(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {key: to_dict(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [to_dict(item) for item in value]
    return value


def validate_knowledge(criteria: Any) -> None:
    """Validate IDs and a dependency DAG; dependencies do not alter rules."""
    try:
        records = tuple(criteria)
    except TypeError as exc:
        raise ValidationError("criteria must be iterable") from exc
    if any(type(criterion) is not CriterionSpec for criterion in records):
        raise ValidationError("criteria must contain CriterionSpec records")
    by_id = {criterion.id: criterion for criterion in records}
    if len(by_id) != len(records):
        raise ValidationError("duplicate criterion identifiers")
    for criterion in records:
        for dependency in criterion.depends_on:
            if dependency not in by_id:
                raise ValidationError(f"unknown dependency {dependency!r} in {criterion.id!r}")
    # Iterative DFS avoids recursion limits for a long, valid dependency chain.
    finished: set[str] = set()
    active: set[str] = set()
    for start in by_id:
        if start in finished:
            continue
        stack = [(start, False)]
        while stack:
            identifier, leaving = stack.pop()
            if leaving:
                active.remove(identifier)
                finished.add(identifier)
                continue
            if identifier in finished:
                continue
            if identifier in active:
                raise ValidationError(f"dependency cycle involving {identifier!r}")
            active.add(identifier)
            stack.append((identifier, True))
            for dependency in reversed(by_id[identifier].depends_on):
                if dependency in active:
                    raise ValidationError(f"dependency cycle involving {dependency!r}")
                if dependency not in finished:
                    stack.append((dependency, False))
