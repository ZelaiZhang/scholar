"""Prefix-safe, byte-budgeted witnesses for the prototype's simple predicates.

Witnesses preserve decisions under the Boolean/numeric/string rule predicates
implemented by this prototype. They do not promise to retain every semantically
important clinical fact. No question history or prior model decision is an input.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Callable

from .ledger import EvidenceLedger
from .models import CriterionSpec, EvidenceClaim, ValidationError, to_dict
from .reasoning import evaluate_criterion, evidence_relation


@dataclass(frozen=True)
class EvidencePacket:
    payload: dict | None
    selected_ids: tuple[str, ...]
    omitted_ids: tuple[str, ...]
    feasible: bool
    cost: int
    cost_unit: str
    reason: str
    input_sha256: str | None


def canonical_payload_json(payload: dict) -> str:
    """The exact serialization used for both payload cost and input hashing."""
    return json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        allow_nan=False,
    )


def _nonnegative_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValidationError(f"{name} must be a nonnegative integer")
    return value


def _claim_sort_key(claim: EvidenceClaim) -> tuple[int, str]:
    return claim.answer.turn_id, claim.id


def _quoted_evidence(claim: EvidenceClaim) -> dict:
    # Source spans and values are copied; bookkeeping such as supersession,
    # extraction confidence, question status, and model decisions stays outside
    # the judging payload.
    return {
        "id": claim.id,
        "criterion_id": claim.criterion_id,
        "facet_id": claim.facet_id,
        "scope_id": claim.scope_id,
        "value": claim.value,
        "question": to_dict(claim.question),
        "answer": to_dict(claim.answer),
    }


def pack_evidence(
    criterion: CriterionSpec,
    ledger: EvidenceLedger,
    *,
    current_turn: int,
    budget: int,
    cost_fn: Callable[[str], int] | None = None,
    cost_unit: str = "utf8_bytes",
) -> EvidencePacket:
    """Pack an atomic required witness envelope, or return no payload.

    The default budget counts UTF-8 bytes of the *entire* canonical JSON payload.
    To count tokens, inject a tokenizer counting this same serialization and
    provide a truthful ``cost_unit``. ``selected_ids`` records the required
    selection even when its envelope is infeasible; an infeasible packet is
    never a request that should be sent to a model.
    """
    _nonnegative_int(current_turn, "current_turn")
    _nonnegative_int(budget, "budget")
    if not isinstance(cost_unit, str) or not cost_unit.strip():
        raise ValidationError("cost_unit must be a nonempty string")
    if cost_fn is not None and not callable(cost_fn):
        raise ValidationError("cost_fn must be callable")
    if cost_fn is None and cost_unit != "utf8_bytes":
        raise ValidationError("a custom cost_unit requires an exact cost_fn")
    if criterion.id not in ledger.criteria or ledger.criteria[criterion.id] != criterion:
        raise ValidationError("criterion must match the ledger knowledge version")

    active = tuple(sorted(
        ledger.active_claims(criterion_id=criterion.id, current_turn=current_turn),
        key=_claim_sort_key,
    ))
    state = evaluate_criterion(criterion, active)
    required: dict[str, EvidenceClaim] = {}
    # Retain the latest deterministic witness for each rule relation. Both sides
    # of a conflict are required as one atomic envelope, never budget-pruned.
    for facet in criterion.facets:
        relations: dict[str, EvidenceClaim] = {}
        for claim in active:
            if claim.facet_id != facet.id or claim.scope_id != facet.scope_id:
                continue
            relation = evidence_relation(facet, claim)
            if relation in {"supported", "refuted"}:
                relations[relation] = claim
        for witness in relations.values():
            required[witness.id] = witness

    selected = tuple(sorted(required.values(), key=_claim_sort_key))
    selected_ids = tuple(claim.id for claim in selected)
    selected_set = set(selected_ids)
    omitted_ids = tuple(claim.id for claim in active if claim.id not in selected_set)
    selected_facets = {claim.facet_id for claim in selected}
    payload = {
        "schema_version": 1,
        "current_turn": current_turn,
        "criterion": to_dict(criterion),
        "evidence": [_quoted_evidence(claim) for claim in selected],
        "coverage": {
            "facet_scopes": [
                {"facet_id": facet.id, "scope_id": facet.scope_id}
                for facet in criterion.facets
            ],
            "selected_facet_ids": [
                facet.id for facet in criterion.facets if facet.id in selected_facets
            ],
            "missing_facet_ids": list(state.missing_facet_ids),
            "selection_limited": bool(omitted_ids),
        },
    }
    serialized = canonical_payload_json(payload)
    measured = (
        len(serialized.encode("utf-8")) if cost_fn is None else cost_fn(serialized)
    )
    cost = _nonnegative_int(measured, "cost_fn result")
    if budget == 0 or cost > budget:
        return EvidencePacket(
            payload=None, selected_ids=selected_ids, omitted_ids=omitted_ids,
            feasible=False, cost=cost, cost_unit=cost_unit,
            reason="required witness envelope exceeds budget; no payload may be sent",
            input_sha256=None,
        )
    return EvidencePacket(
        payload=payload, selected_ids=selected_ids, omitted_ids=omitted_ids,
        feasible=True, cost=cost, cost_unit=cost_unit,
        reason="all required rule witnesses retained; redundant or off-scope claims omitted",
        input_sha256=hashlib.sha256(serialized.encode("utf-8")).hexdigest(),
    )
