"""Prefix replay, evidence packets and independent question planning.

This pipeline consumes extraction proposals. Exact quotation checks validate
grounding, not the meaning/polarity/time assigned by an extractor. It returns
rule-level evidence states, never a diagnosis. Approval of revisions is supplied
by a caller, not inferred from a model's JSON response.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from . import __version__
from .io import digest, validate_json_value
from .ledger import EvidenceLedger, validate_cutoff
from .models import (CriterionSpec, Turn, ValidationError, parse_claim,
                     parse_criterion, parse_turn, to_dict, validate_knowledge)
from .packing import pack_evidence
from .planning import QuestionRecord, plan_question
from .reasoning import affected_criteria, evaluate_all
from .safety import DataPolicy, enforce_text_boundary, json_strings, parse_policy


@dataclass(frozen=True)
class ResearchDocument:
    policy: DataPolicy
    knowledge_version: str
    turns: tuple[Turn, ...]
    criteria: tuple[CriterionSpec, ...]
    raw_claims: tuple[dict, ...]
    approved_revision_ids: frozenset[str]
    acceptance_turns: dict[str, int]
    revision_approval_turns: dict[str, int]
    question_history: tuple[QuestionRecord, ...]
    extraction_runs: tuple[dict, ...]
    input_sha256: str


def _id_list(value: Any, name: str) -> list[str]:
    if type(value) is not list or any(type(v) is not str or not v.strip() for v in value):
        raise ValidationError(name + " must be a list of nonempty IDs")
    if len(set(value)) != len(value):
        raise ValidationError(name + " contains duplicate IDs")
    return value


def parse_document(value: Any) -> ResearchDocument:
    validate_json_value(value)
    required = {"schema_version", "data_policy", "knowledge_version", "turns",
                "criteria", "claims", "approved_revision_ids", "question_history"}
    optional = {"claim_acceptance_turns", "revision_approval_turns", "extraction_runs"}
    if type(value) is not dict or set(value) - required - optional or required - set(value):
        raise ValidationError("document has missing or unknown top-level fields")
    if type(value["schema_version"]) is not int or value["schema_version"] != 1:
        raise ValidationError("only integer schema_version 1 is supported")
    policy = parse_policy(value["data_policy"])
    enforce_text_boundary(json_strings(value))
    version = value["knowledge_version"]
    if type(version) is not str or not version.strip():
        raise ValidationError("knowledge_version is required")
    for field in ("turns", "criteria", "claims", "question_history"):
        if type(value[field]) is not list:
            raise ValidationError(field + " must be a list")
    turns = tuple(parse_turn(item) for item in value["turns"])
    criteria = tuple(parse_criterion(item) for item in value["criteria"])
    if not criteria:
        raise ValidationError("at least one criterion is required")
    validate_knowledge(criteria)
    structure = EvidenceLedger(criteria)
    for turn in turns:
        structure.add_turn(turn)
    raw_claims = tuple(value["claims"])
    # Reject malformed claim objects in replay without coercing them to evidence.
    # Require IDs/cutoffs here to make their replay position unambiguous.
    ids: set[str] = set()
    for item in raw_claims:
        if type(item) is not dict or type(item.get("id")) is not str or not item["id"].strip():
            raise ValidationError("each claim requires an object and a nonempty ID")
        if item["id"] in ids:
            raise ValidationError("duplicate claim IDs in document")
        ids.add(item["id"])
    approved = frozenset(_id_list(value["approved_revision_ids"], "approved_revision_ids"))
    if approved - ids:
        raise ValidationError("approved_revision_ids refers to unknown proposals")
    acceptance = value.get("claim_acceptance_turns", {})
    if type(acceptance) is not dict or set(acceptance) - ids:
        raise ValidationError("claim_acceptance_turns must map known claim IDs to turns")
    resolved_acceptance = {}
    for item in raw_claims:
        answer = item.get("answer", {})
        cutoff = acceptance.get(item["id"], answer.get("turn_id") if type(answer) is dict else None)
        validate_cutoff(cutoff)
        if cutoff not in structure.turns:
            raise ValidationError("a claim acceptance cutoff must identify a stored turn")
        resolved_acceptance[item["id"]] = cutoff
    approval_turns = value.get("revision_approval_turns", {})
    if type(approval_turns) is not dict or set(approval_turns) != set(approved):
        raise ValidationError("every approved revision requires an explicit revision_approval_turns entry")
    for identifier, approval_turn in approval_turns.items():
        validate_cutoff(approval_turn)
        if approval_turn not in structure.turns:
            raise ValidationError("revision approval must identify a stored event turn")
        resolved_acceptance[identifier] = max(resolved_acceptance[identifier], approval_turn)
    history = []
    known_groups = {(f.intent_id, f.scope_id) for c in criteria for f in c.facets}
    for item in value["question_history"]:
        names = {"intent_id", "scope_id", "turn_id", "status", "clarification_count"}
        if type(item) is not dict or set(item) - names or names - {"clarification_count"} - set(item):
            raise ValidationError("invalid question_history record fields")
        try:
            record = QuestionRecord(**item)
        except (TypeError, ValueError) as exc:
            raise ValidationError("invalid question_history record") from exc
        if record.turn_id not in structure.turns or (record.intent_id, record.scope_id) not in known_groups:
            raise ValidationError("question_history references an unknown turn, intent or scope")
        if record.status == "asked" and structure.turns[record.turn_id].role != "assistant":
            raise ValidationError("an asked record must refer to a delivered assistant question")
        if record.status in {"answered", "declined"} and structure.turns[record.turn_id].role != "user":
            raise ValidationError("answered/declined status must refer to its user response turn")
        history.append(record)
    runs = value.get("extraction_runs", [])
    if type(runs) is not list or any(type(r) is not dict for r in runs):
        raise ValidationError("extraction_runs must be a list of provenance objects")
    return ResearchDocument(policy, version, turns, criteria, raw_claims, approved,
                            resolved_acceptance, approval_turns.copy(), tuple(history), tuple(runs), digest(value))


def resolve_prefix(document: ResearchDocument, current_turn: int | None) -> int:
    last = document.turns[-1].id if document.turns else 0
    cutoff = last if current_turn is None else current_turn
    validate_cutoff(cutoff)
    if cutoff > last:
        raise ValidationError("requested prefix exceeds the available conversation")
    if cutoff != 0 and cutoff not in {turn.id for turn in document.turns}:
        raise ValidationError("current_turn must identify an actual source turn or the empty prefix 0")
    return cutoff


def replay_ledger(document: ResearchDocument, *, current_turn: int) -> tuple[EvidenceLedger, list[dict], list[dict]]:
    cutoff = resolve_prefix(document, current_turn)
    ledger = EvidenceLedger(document.criteria)
    rejected, invalidations = [], []
    scheduled: dict[int, list[dict]] = {}
    for raw in document.raw_claims:
        accepted = document.acceptance_turns[raw["id"]]
        if accepted <= cutoff:
            scheduled.setdefault(accepted, []).append(raw)
    for turn in document.turns:
        if turn.id > cutoff:
            break
        ledger.add_turn(turn)
        for raw in scheduled.get(turn.id, []):
            before = evaluate_all(ledger, current_turn=turn.id)
            try:
                claim = parse_claim(raw)
                ledger.add_claim(claim, current_turn=turn.id,
                                 approve_revision=claim.id in document.approved_revision_ids)
            except ValidationError as exc:
                rejected.append({"claim_id": raw["id"], "acceptance_turn": turn.id,
                                 "reason": str(exc)})
                continue
            impacted = affected_criteria(document.criteria, (claim.criterion_id,))
            after = evaluate_all(ledger, current_turn=turn.id)
            invalidations.append({
                "claim_id": claim.id, "acceptance_turn": turn.id,
                "supersedes": list(claim.supersedes), "invalidated_criteria": list(impacted),
                "state_changes": [{"criterion_id": identifier,
                                   "before": before[identifier].status,
                                   "after": after[identifier].status}
                                  for identifier in impacted if before[identifier] != after[identifier]],
            })
    return ledger, rejected, invalidations


def run_pipeline(value: dict, *, current_turn: int | None = None,
                 budget_bytes: int = 8192, max_clarifications: int = 2) -> dict:
    document = parse_document(value)
    cutoff = resolve_prefix(document, current_turn)
    ledger, rejected, invalidations = replay_ledger(document, current_turn=cutoff)
    states = evaluate_all(ledger, current_turn=cutoff)
    packets = {criterion.id: pack_evidence(criterion, ledger, current_turn=cutoff,
                                         budget=budget_bytes) for criterion in document.criteria}
    history = tuple(record for record in document.question_history if record.turn_id <= cutoff)
    plan = plan_question(document.criteria, states, history, current_turn=cutoff,
                         max_clarifications=max_clarifications)
    visible = {
        "knowledge_version": document.knowledge_version,
        "criteria": to_dict(document.criteria), "turns": to_dict(tuple(ledger.turns.values())),
        "accepted_claims": to_dict(tuple(ledger.claims.values())), "question_history": to_dict(history),
        "acceptance_turns": {identifier: document.acceptance_turns[identifier] for identifier in ledger.claims},
        "revision_approval_turns": {identifier: turn for identifier, turn in document.revision_approval_turns.items()
                                    if identifier in ledger.claims},
    }
    extraction_runs = [record for record in document.extraction_runs
                       if type(record.get("acceptance_turn")) is int and record["acceptance_turn"] <= cutoff]
    return {
        "schema_version": 1, "current_turn": cutoff,
        "criterion_states": to_dict(states), "evidence_packets": to_dict(packets),
        "rule_branch_eligible": {identifier: state.status in {"supported", "refuted"}
                                 and packets[identifier].feasible for identifier, state in states.items()},
        "question_plan": to_dict(plan), "rejected_claims": rejected,
        "dependency_invalidations": invalidations,
        "extraction_provenance": extraction_runs,
        "provenance": {
            "prototype_version": __version__, "source_id": document.policy.source_id,
            "source_origin": document.policy.origin,
            "knowledge_version": document.knowledge_version,
            "input_sha256": document.input_sha256, "visible_prefix_sha256": digest(visible),
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "configuration": {"budget_bytes_per_criterion": budget_bytes,
                              "max_clarifications": max_clarifications},
            "model": None, "model_calls": 0, "input_tokens": None, "output_tokens": None,
            "cost_scope": "this local replay only; earlier extraction costs are separate",
            "semantic_values_verified": False,
        },
    }
