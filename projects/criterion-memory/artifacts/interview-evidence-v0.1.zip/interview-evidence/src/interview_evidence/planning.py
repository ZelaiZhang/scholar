"""Deterministic unresolved-coverage planning, separate from evidence judgment.

The score is a count of unresolved criterion/facet references sharing an explicit
intent and event scope. It is not estimated clinical information gain or a
diagnostic recommendation. Plans never mark a facet answered or satisfied.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from .models import CriterionSpec, CriterionState, ValidationError, validate_knowledge


_STATES = {"supported", "refuted", "unknown", "conflicted"}


def _nonnegative_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValidationError(f"{name} must be a nonnegative integer")
    return value


@dataclass(frozen=True)
class QuestionRecord:
    intent_id: str
    scope_id: str
    turn_id: int
    status: str
    clarification_count: int = 0

    def __post_init__(self) -> None:
        for field in ("intent_id", "scope_id"):
            value = getattr(self, field)
            if not isinstance(value, str) or not value.strip():
                raise ValidationError(f"{field} must be a nonempty string")
        if _nonnegative_int(self.turn_id, "turn_id") == 0:
            raise ValidationError("turn_id must be positive")
        if not isinstance(self.status, str) or self.status not in {"asked", "answered", "declined"}:
            raise ValidationError("question status must be asked, answered or declined")
        _nonnegative_int(self.clarification_count, "clarification_count")


@dataclass(frozen=True)
class QuestionPlan:
    action: str
    intent_id: str | None
    scope_id: str | None
    question: str | None
    criterion_ids: tuple[str, ...]
    facet_ids: tuple[str, ...]
    reason: str
    score: int


def _validate_states(
    criteria: tuple[CriterionSpec, ...], states: Mapping[str, CriterionState],
) -> None:
    if not isinstance(states, Mapping):
        raise ValidationError("states must be a mapping")
    known = {criterion.id for criterion in criteria}
    if set(states) != known:
        raise ValidationError("states must contain exactly the supplied criteria")
    for criterion in criteria:
        state = states[criterion.id]
        if not isinstance(state, CriterionState) or state.criterion_id != criterion.id:
            raise ValidationError("criterion state does not match its knowledge ID")
        if state.status not in _STATES:
            raise ValidationError("invalid criterion state status")
        expected = {facet.id: facet.scope_id for facet in criterion.facets}
        actual: dict[str, str] = {}
        for facet_state in state.facets:
            if facet_state.facet_id in actual or facet_state.status not in _STATES:
                raise ValidationError("invalid or duplicate facet state")
            actual[facet_state.facet_id] = facet_state.scope_id
        if actual != expected:
            raise ValidationError("facet states must match the supplied facet IDs and scopes")


def plan_question(
    criteria: Iterable[CriterionSpec],
    states: Mapping[str, CriterionState],
    history: Iterable[QuestionRecord],
    *,
    current_turn: int,
    max_clarifications: int = 2,
) -> QuestionPlan:
    """Choose a bounded question without changing knowledge, states, or history.

    Different scope IDs are never deduplicated. Delivered/answered questions with
    unresolved evidence may receive clarification; a delivery record alone is
    never sufficient evidence. Most recent status and maximum recorded count
    govern each group so a lower later count cannot reset its clarification cap.
    """
    _nonnegative_int(current_turn, "current_turn")
    _nonnegative_int(max_clarifications, "max_clarifications")
    criteria = tuple(criteria)
    records = tuple(history)
    validate_knowledge(criteria)
    _validate_states(criteria, states)
    latest: dict[tuple[str, str], QuestionRecord] = {}
    counts: dict[tuple[str, str], int] = {}
    for record in records:
        if not isinstance(record, QuestionRecord):
            raise ValidationError("history must contain QuestionRecord values")
        if record.turn_id > current_turn:
            raise ValidationError("question history contains a future turn")
        key = record.intent_id, record.scope_id
        previous = latest.get(key)
        if previous is not None and previous.turn_id == record.turn_id and previous != record:
            raise ValidationError("conflicting history records for the same delivered question")
        if previous is None or record.turn_id > previous.turn_id:
            latest[key] = record
        counts[key] = max(counts.get(key, 0), record.clarification_count)

    groups: dict[tuple[str, str], dict] = {}
    for criterion in criteria:
        facet_states = {state.facet_id: state for state in states[criterion.id].facets}
        for facet in criterion.facets:
            facet_state = facet_states[facet.id]
            if facet_state.status not in {"unknown", "conflicted"}:
                continue
            key = facet.intent_id, facet.scope_id
            group = groups.setdefault(key, {
                "question": facet.question, "references": [], "conflicts": 0,
                "order": len(groups),
            })
            group["references"].append((criterion.id, facet.id))
            group["conflicts"] += facet_state.status == "conflicted"
    if not groups:
        return QuestionPlan(
            "none", None, None, None, (), (),
            "no unresolved criterion facets remain", 0,
        )

    ranked = sorted(
        groups.items(),
        key=lambda item: (
            -len(item[1]["references"]), -item[1]["conflicts"], item[1]["order"],
        ),
    )
    blocked: list[QuestionPlan] = []
    for (intent_id, scope_id), group in ranked:
        key = intent_id, scope_id
        record = latest.get(key)
        refs = group["references"]
        criterion_ids = tuple(dict.fromkeys(criterion_id for criterion_id, _ in refs))
        facet_ids = tuple(dict.fromkeys(facet_id for _, facet_id in refs))
        score = len(refs)
        if record is not None and record.status == "declined":
            action, question = "defer", None
            reason = "latest question for this intent and scope was declined"
        elif record is not None or group["conflicts"]:
            if counts.get(key, 0) >= max_clarifications:
                action, question = "defer", None
                reason = "unresolved evidence remains but the clarification limit was reached"
            else:
                action, question = "clarify", "Please clarify: " + group["question"]
                reason = "unresolved evidence requires clarification; question delivery is not evidence"
        else:
            action, question = "ask", group["question"]
            reason = "highest deterministic unresolved-coverage score for an unasked intent and scope"
        plan = QuestionPlan(
            action, intent_id, scope_id, question, criterion_ids, facet_ids, reason, score,
        )
        if action == "defer":
            blocked.append(plan)
        else:
            return plan
    return blocked[0]
