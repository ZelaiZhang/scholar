"""Conservative four-state facet and criterion evaluation.

Rules inspect grounded scalar proposals, not diagnosis labels. Grounding proves
that a quote exists, not that the extraction's semantic interpretation is true.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable, Mapping

from .ledger import EvidenceLedger, validate_cutoff
from .models import (
    CriterionSpec,
    CriterionState,
    EvidenceClaim,
    FacetSpec,
    FacetState,
    ValidationError,
    validate_knowledge,
    validate_value,
)


def evidence_relation(facet: FacetSpec, claim: EvidenceClaim) -> str:
    """Compare a correctly typed same-facet/scope value with its rule.

    Unrelated scopes/facets return unknown and cannot fill a coverage gap.
    Distinct values on the same side of a threshold are consistent at the rule
    level; opposing support/refutation is retained as a conflict by evaluation.
    """
    if type(facet) is not FacetSpec or type(claim) is not EvidenceClaim:
        raise ValidationError("evidence_relation requires FacetSpec and EvidenceClaim")
    if claim.facet_id != facet.id or claim.scope_id != facet.scope_id:
        return "unknown"
    validate_value(claim.value, facet.kind, allow_none=True, name="claim.value")
    if claim.value is None:
        return "unknown"
    if facet.operator == "equals":
        matches = claim.value == facet.target
    elif facet.operator == "gte":
        matches = claim.value >= facet.target
    else:
        matches = claim.value <= facet.target
    return "supported" if matches else "refuted"


def evaluate_criterion(criterion: CriterionSpec, claims: Iterable[EvidenceClaim]) -> CriterionState:
    if type(criterion) is not CriterionSpec:
        raise ValidationError("evaluate_criterion requires a CriterionSpec")
    records = tuple(claims)
    if any(type(claim) is not EvidenceClaim for claim in records):
        raise ValidationError("claims must contain EvidenceClaim records")
    identifiers = [claim.id for claim in records]
    if len(identifiers) != len(set(identifiers)):
        raise ValidationError("claims contain duplicate evidence identifiers")
    facet_states: list[FacetState] = []
    for facet in criterion.facets:
        matching = tuple(claim for claim in records if (
            claim.criterion_id == criterion.id and claim.facet_id == facet.id and claim.scope_id == facet.scope_id
        ))
        relations = {evidence_relation(facet, claim) for claim in matching}
        if {"supported", "refuted"}.issubset(relations):
            status = "conflicted"
        elif "supported" in relations:
            status = "supported"
        elif "refuted" in relations:
            status = "refuted"
        else:
            status = "unknown"
        facet_states.append(FacetState(facet.id, facet.scope_id, status, tuple(claim.id for claim in matching)))
    supported = sum(state.status == "supported" for state in facet_states)
    possible = sum(state.status != "refuted" for state in facet_states)
    needed = len(facet_states) if criterion.logic == "all" else (1 if criterion.logic == "any" else criterion.threshold)
    if supported >= needed:
        aggregate = "supported"
    elif possible < needed:
        aggregate = "refuted"
    elif any(state.status == "conflicted" for state in facet_states):
        aggregate = "conflicted"
    else:
        aggregate = "unknown"
    # Preserve declared facet order and deterministic input evidence order.
    included = {identifier for state in facet_states for identifier in state.evidence_ids}
    evidence_ids = tuple(claim.id for claim in records if claim.id in included)
    missing = tuple(state.facet_id for state in facet_states if state.status in {"unknown", "conflicted"})
    return CriterionState(criterion.id, aggregate, tuple(facet_states), evidence_ids, missing)


def evaluate_all(ledger: EvidenceLedger, *, current_turn: int) -> dict[str, CriterionState]:
    if not isinstance(ledger, EvidenceLedger):
        raise ValidationError("evaluate_all requires an EvidenceLedger")
    validate_cutoff(current_turn)
    records = ledger.active_claims(current_turn=current_turn)
    return {criterion.id: evaluate_criterion(criterion, records) for criterion in ledger.criteria.values()}


def affected_criteria(
    criteria: Iterable[CriterionSpec] | Mapping[str, CriterionSpec], changed_ids: Iterable[str]
) -> tuple[str, ...]:
    """Return changed criteria and transitive dependents in declared order."""
    records = tuple(criteria.values()) if isinstance(criteria, Mapping) else tuple(criteria)
    validate_knowledge(records)
    by_id = {criterion.id: criterion for criterion in records}
    if isinstance(changed_ids, (str, bytes)):
        raise ValidationError("changed_ids must be an iterable of criterion identifiers")
    changes = tuple(changed_ids)
    if any(type(identifier) is not str or identifier not in by_id for identifier in changes):
        raise ValidationError("changed_ids contains unknown criterion identifiers")
    reverse: dict[str, list[str]] = {identifier: [] for identifier in by_id}
    for criterion in records:
        for dependency in criterion.depends_on:
            reverse[dependency].append(criterion.id)
    affected = set(changes)
    pending = deque(dict.fromkeys(changes))
    while pending:
        for dependent in reverse[pending.popleft()]:
            if dependent not in affected:
                affected.add(dependent)
                pending.append(dependent)
    return tuple(criterion.id for criterion in records if criterion.id in affected)
