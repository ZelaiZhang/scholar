"""Explicit research-source policy and a conservative identifier tripwire.

This detector is not a deidentification system. A caller remains responsible for
source authorization and removal of identifying information before input.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Iterable

from .models import Turn, ValidationError


class SourcePolicyError(ValidationError):
    pass


@dataclass(frozen=True)
class DataPolicy:
    source_id: str
    origin: str
    external_api_allowed: bool


def parse_policy(value: Any) -> DataPolicy:
    if type(value) is not dict or set(value) != {
        "source_id", "origin", "external_api_allowed"
    }:
        raise SourcePolicyError("data_policy requires exactly source_id, origin, external_api_allowed")
    if type(value["source_id"]) is not str or not value["source_id"].strip():
        raise SourcePolicyError("a nonempty source_id is required")
    if type(value["origin"]) is not str or value["origin"] not in {"synthetic", "public", "deidentified"}:
        raise SourcePolicyError("origin must be synthetic, public, or researcher-approved deidentified")
    if type(value["external_api_allowed"]) is not bool:
        raise SourcePolicyError("external_api_allowed requires an explicit boolean")
    return DataPolicy(**value)


_IDENTIFIERS = (
    re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    re.compile(r"(?<![A-Za-z0-9])1[3-9]\d{9}(?![A-Za-z0-9])"),
    re.compile(r"(?<![A-Za-z0-9])\d{17}[\dXx](?![A-Za-z0-9])"),
    re.compile(r"(?:住院号|病案号|身份证号|患者姓名|联系电话|hospital\s*id|patient\s*name)\s*[:：]\s*\S+", re.I),
)


def enforce_input_boundary(turns: Iterable[Turn]) -> None:
    enforce_text_boundary(turn.text for turn in turns)


def enforce_text_boundary(texts: Iterable[str]) -> None:
    for text in texts:
        if any(pattern.search(text) for pattern in _IDENTIFIERS):
            # Do not echo the matched identifier into an error/log.
            raise SourcePolicyError("possible identifying health information: stop and deidentify the source before input")


def json_strings(value: Any) -> Iterable[str]:
    if type(value) is str:
        yield value
    elif type(value) is dict:
        for key, item in value.items():
            yield key
            yield from json_strings(item)
    elif type(value) is list:
        for item in value:
            yield from json_strings(item)


def authorize_external(policy: DataPolicy) -> None:
    if not policy.external_api_allowed:
        raise SourcePolicyError("external transport denied by this source's explicit policy")
