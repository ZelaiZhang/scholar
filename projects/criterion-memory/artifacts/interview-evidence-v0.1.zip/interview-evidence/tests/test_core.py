"""Synthetic structural tests; these do not measure medical effectiveness."""

from dataclasses import FrozenInstanceError, replace
import json
import math
import unittest

from interview_evidence.ledger import EvidenceLedger
from interview_evidence.models import (
    CriterionSpec, EvidenceClaim, FacetSpec, Span, Turn, ValidationError,
    parse_claim, parse_criterion, parse_turn, to_dict, validate_knowledge,
)
from interview_evidence.reasoning import affected_criteria, evaluate_all, evaluate_criterion, evidence_relation


def facet(identifier="flag", *, kind="boolean", operator="equals", target=True, scope="current"):
    return FacetSpec(identifier, kind, operator, target, scope, "Synthetic criterion question?", identifier)


def criterion(identifier="C", *, facets=None, logic="all", threshold=None, depends_on=()):
    return CriterionSpec(identifier, "Synthetic criterion", tuple(facets or [facet()]), logic, threshold, depends_on)


def claim(identifier="E", *, value=True, criterion_id="C", facet_id="flag", scope="current", q=1, a=2, supersedes=()):
    return EvidenceClaim(identifier, criterion_id, facet_id, value, scope, Span(q, 0, 1, "Q"), Span(a, 0, 1, "A"), supersedes)


def ledger_with_pairs(criteria=None, pairs=3):
    result = EvidenceLedger(criteria or [criterion()])
    for number in range(pairs):
        result.add_turn(Turn(2 * number + 1, "assistant", "Q"))
        result.add_turn(Turn(2 * number + 2, "user", "A", 2 * number + 1))
    return result


class ModelValidationTests(unittest.TestCase):
    def test_round_trip_strict_json_records(self):
        records = [Turn(1, "assistant", "Q"), criterion(), claim()]
        parsers = [parse_turn, parse_criterion, parse_claim]
        for record, parser in zip(records, parsers):
            self.assertEqual(record, parser(json.loads(json.dumps(to_dict(record)))))

    def test_models_immutable_and_nested_arrays_are_tuples(self):
        record = parse_criterion(to_dict(criterion()))
        self.assertIs(type(record.facets), tuple)
        with self.assertRaises(FrozenInstanceError):
            record.label = "rewritten"
        with self.assertRaises(ValidationError):
            CriterionSpec("C", "label", [facet()])

    def test_unknown_keys_rejected_at_each_level(self):
        for record, parser in ((Turn(1, "assistant", "Q"), parse_turn), (criterion(), parse_criterion), (claim(), parse_claim)):
            data = to_dict(record)
            data["untrusted_field"] = True
            with self.assertRaises(ValidationError):
                parser(data)
        nested = to_dict(claim())
        nested["answer"]["confidence"] = 1.0
        with self.assertRaises(ValidationError):
            parse_claim(nested)
        nested = to_dict(criterion())
        nested["facets"][0]["confidence"] = 1.0
        with self.assertRaises(ValidationError):
            parse_criterion(nested)

    def test_missing_non_object_and_non_json_array_rejected(self):
        for data in ({}, [], None, {1: "bad key"}):
            with self.assertRaises(ValidationError):
                parse_turn(data)
        data = to_dict(criterion())
        data["facets"] = tuple(data["facets"])
        with self.assertRaises(ValidationError):
            parse_criterion(data)

    def test_bool_is_not_integer_or_number(self):
        for identifier in (True, False, 1.0, "1"):
            with self.assertRaises(ValidationError):
                Turn(identifier, "assistant", "Q")
        with self.assertRaises(ValidationError):
            facet(kind="number", operator="gte", target=True)
        with self.assertRaises(ValidationError):
            criterion(logic="at_least", threshold=True)
        with self.assertRaises(ValidationError):
            Span(1, False, 1, "Q")

    def test_non_finite_numeric_values_rejected(self):
        for value in (math.nan, math.inf, -math.inf):
            with self.assertRaises(ValidationError):
                facet(kind="number", target=value)
            with self.assertRaises(ValidationError):
                claim(value=value)

    def test_facet_operator_target_and_threshold_rules(self):
        for invalid in (
            lambda: facet(kind="boolean", operator="gte"),
            lambda: facet(kind="boolean", target=1),
            lambda: facet(kind="string", target=True),
            lambda: facet(operator="contains"),
            lambda: criterion(logic="at_least", threshold=0),
            lambda: criterion(logic="at_least", threshold=2),
            lambda: criterion(threshold=1),
            lambda: criterion(logic="xor"),
        ):
            with self.assertRaises(ValidationError):
                invalid()

    def test_empty_duplicate_facets_and_dependencies_rejected(self):
        with self.assertRaises(ValidationError):
            CriterionSpec("C", "label", ())
        with self.assertRaises(ValidationError):
            criterion(facets=[facet(), facet()])
        with self.assertRaises(ValidationError):
            criterion(depends_on=("D", "D"))

    def test_span_unicode_length_and_ranges(self):
        self.assertEqual(Span(1, 2, 4, "医🩺").quote, "医🩺")
        for start, end, quote in ((0, 0, ""), (-1, 0, "Q"), (0, 4, "医🩺")):
            with self.assertRaises(ValidationError):
                Span(1, start, end, quote)

    def test_invalid_turn_roles_and_links(self):
        for arguments in ((1, "doctor", "Q"), (2, "assistant", "Q", 1), (2, "user", "A", 2)):
            with self.assertRaises(ValidationError):
                Turn(*arguments)


class LedgerGroundingTests(unittest.TestCase):
    def test_unicode_codepoints_ground_both_question_and_answer(self):
        ledger = EvidenceLedger([criterion()])
        ledger.add_turn(Turn(1, "assistant", "问🩺？"))
        ledger.add_turn(Turn(2, "user", "答：是🧠", 1))
        evidence = replace(claim(), question=Span(1, 0, 3, "问🩺？"), answer=Span(2, 2, 4, "是🧠"))
        ledger.add_claim(evidence, current_turn=2)
        self.assertEqual(ledger.active_claims(current_turn=2), (evidence,))

    def test_paraphrases_and_wrong_offsets_are_rejected(self):
        ledger = ledger_with_pairs()
        for evidence in (
            replace(claim(), answer=Span(2, 0, 1, "B")),
            replace(claim(), question=Span(1, 0, 1, "R")),
            replace(claim(), answer=Span(2, 1, 2, "A")),
        ):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=2)
            self.assertEqual(ledger.claims, {})

    def test_question_answer_role_and_direct_pair_link(self):
        ledger = ledger_with_pairs()
        for evidence in (
            replace(claim(), question=Span(2, 0, 1, "A")),
            replace(claim(), answer=Span(1, 0, 1, "Q")),
            replace(claim(), answer=Span(4, 0, 1, "A")),
        ):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=4)
        unlinked = EvidenceLedger([criterion()])
        unlinked.add_turn(Turn(1, "assistant", "Q"))
        unlinked.add_turn(Turn(2, "user", "A"))
        with self.assertRaises(ValidationError):
            unlinked.add_claim(claim(), current_turn=2)

    def test_turn_append_order_and_link_validation(self):
        ledger = ledger_with_pairs(pairs=1)
        for turn in (Turn(1, "assistant", "Q"), Turn(3, "user", "A", 2), Turn(4, "user", "A", 3)):
            with self.assertRaises(ValidationError):
                ledger.add_turn(turn)
        ledger.add_turn(Turn(4, "assistant", "Q"))
        with self.assertRaises(ValidationError):
            ledger.add_turn(Turn(3, "assistant", "Q"))
        self.assertEqual(tuple(ledger.turns), (1, 2, 4))

    def test_future_nonexistent_sources_and_cutoffs_rejected(self):
        ledger = ledger_with_pairs()
        for evidence, cutoff in ((claim(), 1), (claim(a=8), 6), (claim(), 0), (claim(), 7), (claim(), True)):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=cutoff)
        with self.assertRaises(ValidationError):
            ledger.active_claims(current_turn=-1)

    def test_unknown_criterion_facet_and_wrong_value_type_rejected(self):
        ledger = ledger_with_pairs()
        for evidence in (claim(criterion_id="missing"), claim(facet_id="missing"), claim(value=1)):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=2)
        numeric = ledger_with_pairs([criterion(facets=[facet(kind="number", operator="gte", target=2)])])
        with self.assertRaises(ValidationError):
            numeric.add_claim(claim(value=True), current_turn=2)

    def test_duplicate_ids_do_not_overwrite(self):
        ledger = ledger_with_pairs()
        original = claim()
        ledger.add_claim(original, current_turn=2)
        with self.assertRaises(ValidationError):
            ledger.add_claim(claim(value=False), current_turn=2)
        self.assertEqual(ledger.claims["E"], original)

    def test_public_snapshots_cannot_rewrite_ledger(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim(), current_turn=2)
        ledger.turns.clear()
        ledger.claims.clear()
        ledger.criteria.clear()
        self.assertEqual(len(ledger.turns), 6)
        self.assertEqual(len(ledger.claims), 1)
        self.assertEqual(len(ledger.criteria), 1)

    def test_late_annotation_does_not_rewrite_historical_prefix(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim(), current_turn=4)
        self.assertEqual(ledger.active_claims(current_turn=2), ())
        self.assertEqual(ledger.active_claims(current_turn=4)[0].id, "E")
        with self.assertRaises(ValidationError):
            ledger.add_claim(claim("earlier"), current_turn=2)


class RevisionTests(unittest.TestCase):
    def test_revision_requires_explicit_approval_and_keeps_old_record(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim("old"), current_turn=2)
        correction = claim("new", value=False, q=3, a=4, supersedes=("old",))
        with self.assertRaises(ValidationError):
            ledger.add_claim(correction, current_turn=4)
        self.assertEqual(tuple(ledger.claims), ("old",))
        ledger.add_claim(correction, current_turn=4, approve_revision=True)
        self.assertEqual(tuple(ledger.claims), ("old", "new"))
        self.assertEqual([c.id for c in ledger.active_claims()], ["new"])

    def test_future_supersession_does_not_leak_into_historical_replay(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim("old"), current_turn=2)
        ledger.add_claim(claim("middle", value=False, q=3, a=4, supersedes=("old",)), current_turn=4, approve_revision=True)
        ledger.add_claim(claim("new", q=5, a=6, supersedes=("middle",)), current_turn=6, approve_revision=True)
        for cutoff, active_id, state in ((0, None, "unknown"), (2, "old", "supported"), (4, "middle", "refuted"), (6, "new", "supported")):
            with self.subTest(cutoff=cutoff):
                records = ledger.active_claims(current_turn=cutoff)
                self.assertEqual([c.id for c in records], [] if active_id is None else [active_id])
                self.assertEqual(evaluate_all(ledger, current_turn=cutoff)["C"].status, state)

    def test_revision_target_must_be_active_and_strictly_older(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim("old"), current_turn=2)
        for evidence in (claim("same", supersedes=("old",)), claim("missing", q=3, a=4, supersedes=("not_there",))):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=4, approve_revision=True)
        ledger.add_claim(claim("new", q=3, a=4, supersedes=("old",)), current_turn=4, approve_revision=True)
        with self.assertRaises(ValidationError):
            ledger.add_claim(claim("third", q=5, a=6, supersedes=("old",)), current_turn=6, approve_revision=True)

    def test_cross_scope_and_cross_facet_revision_rejected(self):
        ledger = ledger_with_pairs([criterion(facets=[facet(), facet("other")]), criterion("D")])
        ledger.add_claim(claim("old"), current_turn=2)
        for evidence in (
            claim("cross_period", scope="past", q=3, a=4, supersedes=("old",)),
            claim("cross_facet", facet_id="other", q=3, a=4, supersedes=("old",)),
            claim("cross_criterion", criterion_id="D", q=3, a=4, supersedes=("old",)),
        ):
            with self.assertRaises(ValidationError):
                ledger.add_claim(evidence, current_turn=4, approve_revision=True)
        self.assertEqual(tuple(ledger.claims), ("old",))

    def test_multitarget_revision_validates_every_target_atomically(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim("positive"), current_turn=2)
        ledger.add_claim(claim("negative", value=False), current_turn=2)
        with self.assertRaises(ValidationError):
            ledger.add_claim(claim("bad", q=3, a=4, supersedes=("positive", "missing")), current_turn=4, approve_revision=True)
        self.assertEqual(tuple(ledger.claims), ("positive", "negative"))
        ledger.add_claim(claim("fixed", q=3, a=4, supersedes=("positive", "negative")), current_turn=4, approve_revision=True)
        self.assertEqual([c.id for c in ledger.active_claims()], ["fixed"])

    def test_contradiction_without_approved_revision_remains_conflict(self):
        ledger = ledger_with_pairs()
        ledger.add_claim(claim("yes"), current_turn=2)
        ledger.add_claim(claim("no", value=False, q=3, a=4), current_turn=4)
        self.assertEqual(evaluate_all(ledger, current_turn=4)["C"].status, "conflicted")


class ReasoningTests(unittest.TestCase):
    def test_missing_unknown_not_negative_and_none_remains_unknown(self):
        rule = criterion()
        self.assertEqual(evaluate_criterion(rule, []).status, "unknown")
        null = evaluate_criterion(rule, [claim(value=None)])
        self.assertEqual(null.status, "unknown")
        self.assertEqual(null.evidence_ids, ("E",))
        self.assertEqual(null.missing_facet_ids, ("flag",))
        self.assertEqual(evaluate_criterion(rule, [claim(value=False)]).status, "refuted")

    def test_other_period_and_criterion_ignored(self):
        records = [claim("past", scope="past"), claim("other", criterion_id="D")]
        state = evaluate_criterion(criterion(), records)
        self.assertEqual(state.status, "unknown")
        self.assertEqual(state.evidence_ids, ())

    def test_unknown_does_not_override_existing_support(self):
        state = evaluate_criterion(criterion(), [claim("yes"), claim("unknown", value=None)])
        self.assertEqual(state.status, "supported")
        self.assertEqual(state.evidence_ids, ("yes", "unknown"))

    def test_numeric_rule_relations_and_boundary_equality(self):
        for operator, value, expected in (("gte", 4, "supported"), ("gte", 3.9, "refuted"), ("lte", 4, "supported"), ("lte", 4.1, "refuted")):
            rule = facet(kind="number", operator=operator, target=4)
            self.assertEqual(evidence_relation(rule, claim(value=value)), expected)
        rule = criterion(facets=[facet(kind="number", operator="gte", target=4)])
        self.assertEqual(evaluate_criterion(rule, [claim("five", value=5), claim("six", value=6)]).status, "supported")
        self.assertEqual(evaluate_criterion(rule, [claim("three", value=3), claim("six", value=6)]).status, "conflicted")

    def test_string_equality_and_boolean_type_rejection(self):
        rule = facet(kind="string", target="synthetic")
        self.assertEqual(evidence_relation(rule, claim(value="synthetic")), "supported")
        self.assertEqual(evidence_relation(rule, claim(value="other")), "refuted")
        with self.assertRaises(ValidationError):
            evaluate_criterion(criterion(), [claim(value=1)])

    def test_all_and_any_decisive_evidence_preserves_unresolved_facets(self):
        facets = [facet("a"), facet("b")]
        negative = claim("negative", facet_id="a", value=False)
        positive = claim("positive", facet_id="a")
        all_state = evaluate_criterion(criterion(facets=facets), [negative])
        self.assertEqual(all_state.status, "refuted")
        self.assertEqual(all_state.missing_facet_ids, ("b",))
        any_state = evaluate_criterion(criterion(facets=facets, logic="any"), [positive])
        self.assertEqual(any_state.status, "supported")
        self.assertEqual(any_state.missing_facet_ids, ("b",))

    def test_conservative_threshold_bounds(self):
        rule = criterion(facets=[facet("a"), facet("b"), facet("c")], logic="at_least", threshold=2)
        records = [claim("a", facet_id="a")]
        self.assertEqual(evaluate_criterion(rule, records).status, "unknown")
        records.append(claim("b", facet_id="b"))
        self.assertEqual(evaluate_criterion(rule, records).status, "supported")
        records = [claim("a", facet_id="a", value=False), claim("b", facet_id="b", value=False)]
        self.assertEqual(evaluate_criterion(rule, records).status, "refuted")
        records = [claim("a", facet_id="a"), claim("yes", facet_id="b"), claim("no", facet_id="b", value=False)]
        self.assertEqual(evaluate_criterion(rule, records).status, "conflicted")

    def test_decisive_threshold_can_resolve_despite_irrelevant_conflict(self):
        facets = [facet("a"), facet("b"), facet("c")]
        conflict = [claim("yes", facet_id="c"), claim("no", facet_id="c", value=False)]
        supported = [claim("a", facet_id="a"), claim("b", facet_id="b")] + conflict
        refuted = [claim("a", facet_id="a", value=False), claim("b", facet_id="b", value=False)] + conflict
        rule = criterion(facets=facets, logic="at_least", threshold=2)
        self.assertEqual(evaluate_criterion(rule, supported).status, "supported")
        self.assertEqual(evaluate_criterion(rule, refuted).status, "refuted")
        self.assertEqual(evaluate_criterion(rule, supported).missing_facet_ids, ("c",))

    def test_duplicate_evidence_identifiers_rejected(self):
        with self.assertRaises(ValidationError):
            evaluate_criterion(criterion(), [claim(), claim(value=False)])


class DependencyTests(unittest.TestCase):
    def test_dependency_unknown_self_cycle_and_multinode_cycle_rejected(self):
        examples = (
            [criterion(depends_on=("unknown",))],
            [criterion(depends_on=("C",))],
            [criterion("A", depends_on=("B",)), criterion("B", depends_on=("A",))],
            [criterion("C"), criterion("C")],
        )
        for records in examples:
            with self.assertRaises(ValidationError):
                validate_knowledge(records)

    def test_diamond_dag_and_transitive_affected_set_stable_order(self):
        records = [criterion("D", depends_on=("B", "C")), criterion("C", depends_on=("A",)), criterion("B", depends_on=("A",)), criterion("A"), criterion("unrelated")]
        validate_knowledge(records)
        self.assertEqual(affected_criteria(records, ["A"]), ("D", "C", "B", "A"))
        self.assertEqual(affected_criteria({record.id: record for record in records}, ["B"]), ("D", "B"))
        self.assertEqual(affected_criteria(records, []), ())
        with self.assertRaises(ValidationError):
            affected_criteria(records, ["unknown"])

    def test_long_chain_without_recursion_limit(self):
        records = [criterion(f"C{number}", depends_on=(f"C{number + 1}",) if number < 1199 else ()) for number in range(1200)]
        validate_knowledge(records)
        self.assertEqual(len(affected_criteria(records, ["C1199"])), 1200)

    def test_dependencies_do_not_become_boolean_prerequisites(self):
        ledger = ledger_with_pairs([criterion("A"), criterion("B", depends_on=("A",))])
        ledger.add_claim(claim(criterion_id="B"), current_turn=2)
        states = evaluate_all(ledger, current_turn=2)
        self.assertEqual(states["A"].status, "unknown")
        self.assertEqual(states["B"].status, "supported")


if __name__ == "__main__":
    unittest.main()
