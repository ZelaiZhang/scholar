"""Integration checks on synthetic fixtures; these are not medical evaluations."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import tempfile
import unittest

from interview_evidence.cli import main
from interview_evidence.demo import empty_extraction_document, synthetic_document
from interview_evidence.extraction import (ExtractionFailure, TransportReply, build_request,
                                           extract_with_transport, ingest_response, submit_approved_revision)
from interview_evidence.io import loads_json, write_new_json
from interview_evidence.models import ValidationError
from interview_evidence.pipeline import parse_document, run_pipeline
from interview_evidence.safety import SourcePolicyError


class PipelineTests(unittest.TestCase):
    def test_replay_and_revision_invalidation(self):
        value = synthetic_document()
        initial = run_pipeline(value, current_turn=8)
        updated = run_pipeline(value, current_turn=10)
        self.assertEqual(initial["criterion_states"]["current"]["status"], "supported")
        self.assertEqual(initial["criterion_states"]["impact"]["status"], "unknown")
        self.assertEqual(updated["criterion_states"]["current"]["status"], "refuted")
        self.assertEqual(updated["criterion_states"]["past"]["status"], "supported")
        event = next(e for e in updated["dependency_invalidations"] if e["claim_id"] == "current-duration-v2")
        self.assertEqual(set(event["invalidated_criteria"]), {"current", "impact", "combined"})
        self.assertEqual(updated["rejected_claims"], [])

    def test_conflict_and_explicit_resolution(self):
        value = synthetic_document()
        conflict = run_pipeline(value, current_turn=12)
        resolved = run_pipeline(value, current_turn=14)
        self.assertEqual(conflict["criterion_states"]["current"]["facets"][0]["status"], "conflicted")
        ids = conflict["evidence_packets"]["current"]["selected_ids"]
        self.assertIn("current-present-v1", ids)
        self.assertIn("current-present-v2", ids)
        self.assertEqual(resolved["criterion_states"]["current"]["facets"][0]["status"], "refuted")
        self.assertNotIn("current-present-v1", resolved["evidence_packets"]["current"]["selected_ids"])

    def test_initial_prefix_and_budget_stop(self):
        initial = run_pipeline(synthetic_document(), current_turn=0)
        self.assertTrue(all(s["status"] == "unknown" for s in initial["criterion_states"].values()))
        stopped = run_pipeline(synthetic_document(), budget_bytes=0)
        self.assertFalse(any(stopped["rule_branch_eligible"].values()))
        self.assertTrue(all(packet["payload"] is None for packet in stopped["evidence_packets"].values()))

    def test_bad_quote_rejected_not_converted_to_negative(self):
        value = synthetic_document()
        value["claims"][0]["answer"]["quote"] = "假" * len(value["claims"][0]["answer"]["quote"])
        output = run_pipeline(value, current_turn=2)
        self.assertEqual(output["criterion_states"]["current"]["status"], "unknown")
        self.assertEqual(output["rejected_claims"][0]["claim_id"], "current-present-v1")

    def test_de_dup_history_changes_plan_not_judgment_packet(self):
        value = synthetic_document()
        a = run_pipeline(value, current_turn=8)
        value["question_history"] = []
        b = run_pipeline(value, current_turn=8)
        self.assertEqual(a["evidence_packets"], b["evidence_packets"])
        self.assertEqual(a["criterion_states"], b["criterion_states"])
        self.assertEqual(a["question_plan"]["action"], "clarify")
        self.assertEqual(b["question_plan"]["action"], "ask")
        self.assertEqual(a["question_plan"]["score"], 2)

    def test_revisions_without_approval_do_not_rewrite(self):
        value = synthetic_document()
        value["approved_revision_ids"] = []
        value["revision_approval_turns"] = {}
        output = run_pipeline(value, current_turn=10)
        self.assertEqual(output["criterion_states"]["current"]["status"], "supported")
        self.assertEqual(len(output["rejected_claims"]), 2)

    def test_late_approval_does_not_rewrite_early_prefix(self):
        value = synthetic_document()
        value["revision_approval_turns"]["current-duration-v2"] = 14
        output = run_pipeline(value, current_turn=10)
        self.assertEqual(output["criterion_states"]["current"]["facets"][1]["status"], "supported")
        final = run_pipeline(value)
        self.assertEqual(final["criterion_states"]["current"]["facets"][1]["status"], "refuted")

    def test_approval_time_is_required(self):
        value = synthetic_document()
        del value["revision_approval_turns"]
        with self.assertRaises(ValidationError):
            parse_document(value)

    def test_prefix_hash_and_packets_ignore_future_turn_text(self):
        value = synthetic_document()
        a = run_pipeline(value, current_turn=8)
        value["turns"][-1]["text"] = "future unrelated change"
        b = run_pipeline(value, current_turn=8)
        self.assertEqual(a["evidence_packets"], b["evidence_packets"])
        self.assertEqual(a["provenance"]["visible_prefix_sha256"], b["provenance"]["visible_prefix_sha256"])
        self.assertNotEqual(a["provenance"]["input_sha256"], b["provenance"]["input_sha256"])

    def test_readonly_pipeline_and_honest_provenance(self):
        value = synthetic_document()
        before = copy.deepcopy(value)
        result = run_pipeline(value)
        self.assertEqual(value, before)
        self.assertEqual(result["provenance"]["model_calls"], 0)
        self.assertIsNone(result["provenance"]["input_tokens"])
        self.assertFalse(result["provenance"]["semantic_values_verified"])


class ExtractionTests(unittest.TestCase):
    def proposal(self):
        claim = copy.deepcopy(synthetic_document()["claims"][0])
        del claim["origin"]
        return claim

    def test_request_only_includes_prefix_knowledge_raw_turns(self):
        value = synthetic_document()
        a = build_request(value, current_turn=2, model="researcher-model")
        prompt = json.loads(a.messages[1]["content"])
        self.assertEqual([t["id"] for t in prompt["turns"]], [1, 2])
        self.assertNotIn("claims", prompt)
        self.assertNotIn("approved_revision_ids", prompt)
        self.assertNotIn("question_history", prompt)
        value["question_history"] = []
        self.assertEqual(a, build_request(value, current_turn=2, model="researcher-model"))

    def test_source_gate_before_transport_call(self):
        called = []
        with self.assertRaises(SourcePolicyError):
            extract_with_transport(empty_extraction_document(), lambda r: called.append(r), model="fake")
        self.assertEqual(called, [])

    def test_explicitly_authorized_fake_transport_tracks_null_usage(self):
        value = empty_extraction_document()
        value["data_policy"]["external_api_allowed"] = True
        updated, report = extract_with_transport(value, lambda request: TransportReply(json.dumps({"claims": [self.proposal()]})),
                                                current_turn=8, model="synthetic-stub-no-network")
        identifier = report["accepted_ids"][0]
        self.assertEqual(report["id_mappings"][0]["proposal_id"], "current-present-v1")
        self.assertIsNone(report["input_tokens"])
        self.assertIsNone(report["output_tokens"])
        self.assertEqual(updated["claim_acceptance_turns"][identifier], 8)
        self.assertEqual(run_pipeline(updated, current_turn=2)["criterion_states"]["current"]["status"], "unknown")
        self.assertEqual(run_pipeline(updated, current_turn=8)["criterion_states"]["current"]["facets"][0]["status"], "supported")

    def test_model_cannot_grant_approval_or_origin(self):
        value = empty_extraction_document()
        proposal = self.proposal()
        proposal["approve_revision"] = True
        updated, report = ingest_response(value, json.dumps({"claims": [proposal]}), current_turn=8)
        self.assertEqual(updated["claims"], [])
        self.assertEqual(len(report["rejected"]), 1)
        with self.assertRaises(ValidationError):
            ingest_response(value, '{"claims": [], "approved_revision_ids": []}', current_turn=8)

    def test_fabricated_and_future_quotes_rejected(self):
        value = empty_extraction_document()
        bad = self.proposal()
        bad["answer"]["quote"] = "X" * len(bad["answer"]["quote"])
        future = copy.deepcopy(synthetic_document()["claims"][-1])
        del future["origin"]
        updated, report = ingest_response(value, json.dumps({"claims": [bad, future]}), current_turn=8)
        self.assertEqual(updated["claims"], [])
        self.assertEqual(len(report["rejected"]), 2)

    def test_request_mismatch_rejected(self):
        value = empty_extraction_document()
        request = build_request(value, current_turn=2, model="fake")
        with self.assertRaises(ValidationError):
            ingest_response(value, '{"claims": []}', current_turn=8, request=request)

    def test_semantically_wrong_but_grounded_value_not_claimed_verified(self):
        proposal = self.proposal()
        proposal["value"] = False  # Structurally valid but contradicts the toy answer meaning.
        updated, report = ingest_response(empty_extraction_document(), json.dumps({"claims": [proposal]}), current_turn=2)
        self.assertEqual(report["id_mappings"][0]["proposal_id"], proposal["id"])
        self.assertFalse(report["semantic_values_verified"])
        self.assertEqual(run_pipeline(updated, current_turn=2)["criterion_states"]["current"]["status"], "refuted")

    def test_future_id_collision_has_no_effect_on_visible_admission(self):
        value = empty_extraction_document()
        response = json.dumps({"claims": [self.proposal()]})
        a, report_a = ingest_response(value, response, current_turn=2)
        collision = copy.deepcopy(synthetic_document()["claims"][1])
        collision["id"] = report_a["accepted_ids"][0]
        value["claims"].append(collision)
        value["claim_acceptance_turns"][collision["id"]] = 4
        b, report_b = ingest_response(value, response, current_turn=2)
        self.assertEqual(a["claims"], b["claims"])
        self.assertEqual(report_a["accepted_ids"], report_b["accepted_ids"])
        self.assertEqual(run_pipeline(a)["criterion_states"], run_pipeline(b)["criterion_states"])
        self.assertEqual([t["id"] for t in b["turns"]], [1, 2])

    def test_same_proposal_id_across_rounds_gets_distinct_ledger_ids(self):
        value = empty_extraction_document()
        first = self.proposal()
        first["id"] = "e1"
        updated, a = ingest_response(value, json.dumps({"claims": [first]}), current_turn=2)
        updated["turns"] = copy.deepcopy(value["turns"][:4])
        second = copy.deepcopy(synthetic_document()["claims"][1])
        del second["origin"]
        second["id"] = "e1"
        updated, b = ingest_response(updated, json.dumps({"claims": [second]}), current_turn=4)
        self.assertNotEqual(a["accepted_ids"], b["accepted_ids"])
        self.assertEqual(len(updated["claims"]), 2)
        self.assertEqual(run_pipeline(updated)["criterion_states"]["current"]["status"], "supported")

    def test_invalid_model_response_preserves_usage_receipt(self):
        value = empty_extraction_document()
        value["data_policy"]["external_api_allowed"] = True
        with self.assertRaises(ExtractionFailure) as context:
            extract_with_transport(value, lambda request: TransportReply("invalid", 10, 2), model="fake", current_turn=2)
        self.assertEqual(context.exception.receipt["input_tokens"], 10)
        self.assertEqual(context.exception.receipt["output_tokens"], 2)
        self.assertEqual(context.exception.receipt["transport_model_calls"], 1)
        self.assertEqual(context.exception.receipt["status"], "response_validation_failed")

    def test_integer_overflow_parser_failure_keeps_cost_receipt(self):
        value = empty_extraction_document()
        value["data_policy"]["external_api_allowed"] = True
        huge = '{"claims":[' + '9' * 10000 + ']}'
        with self.assertRaises(ExtractionFailure) as context:
            extract_with_transport(value, lambda request: TransportReply(huge, 20, 3), model="fake", current_turn=2)
        self.assertEqual(context.exception.receipt["input_tokens"], 20)

    def test_approved_revision_api_preserves_past(self):
        value = synthetic_document()
        proposal = copy.deepcopy(value["claims"][7])
        proposal["id"] = "human-duration-correction"
        value["claims"] = value["claims"][:7]
        value["approved_revision_ids"] = []
        value["revision_approval_turns"] = {}
        value["claim_acceptance_turns"] = {raw["id"]: raw["answer"]["turn_id"] for raw in value["claims"]}
        updated = submit_approved_revision(value, proposal, approval_turn=14)
        self.assertEqual(run_pipeline(updated, current_turn=10)["criterion_states"]["current"]["status"], "supported")
        self.assertEqual(run_pipeline(updated, current_turn=14)["criterion_states"]["current"]["status"], "refuted")


class InputBoundaryTests(unittest.TestCase):
    def test_identifier_tripwire_stops_without_echo(self):
        value = empty_extraction_document()
        value["turns"][1]["text"] = "住院号: SYNTHETIC-ID"
        with self.assertRaises(SourcePolicyError) as context:
            parse_document(value)
        self.assertNotIn("SYNTHETIC-ID", str(context.exception))

    def test_no_duplicate_json_or_nan(self):
        for text in ('{"claims": [], "claims": []}', '{"value": NaN}', '{"value":1e400}', '{"id":"\\ud800"}'):
            with self.assertRaises(ValidationError):
                loads_json(text)

    def test_identifiers_in_knowledge_are_also_blocked(self):
        value = empty_extraction_document()
        value["criteria"][0]["label"] = "patient name: SYNTHETIC-ONLY"
        with self.assertRaises(SourcePolicyError):
            build_request(value, current_turn=2, model="fake")

    def test_new_response_identifiers_are_blocked_before_return(self):
        value = empty_extraction_document()
        proposal = copy.deepcopy(synthetic_document()["claims"][0])
        del proposal["origin"]
        proposal["id"] = "synthetic@example.invalid"
        with self.assertRaises(SourcePolicyError):
            ingest_response(value, json.dumps({"claims": [proposal]}), current_turn=2)
        self.assertEqual(value["claims"], [])

    def test_generated_hex_digest_does_not_trip_identifier_detector(self):
        value = empty_extraction_document()
        value["extraction_runs"] = [{"response_sha256": "a13800138000b" + "c" * 52, "acceptance_turn": 2}]
        parse_document(value)

    def test_parameter_keys_are_not_coerced(self):
        with self.assertRaises(ValidationError):
            build_request(empty_extraction_document(), model="fake", parameters={"nested": {1: "x"}})

    def test_gap_cutoff_rejected_before_transport(self):
        value = empty_extraction_document()
        value["turns"] = [value["turns"][0], {"id": 3, "role": "user", "text": "synthetic answer", "reply_to": 1}]
        value["question_history"] = []
        value["data_policy"]["external_api_allowed"] = True
        called = []
        with self.assertRaises(ValidationError):
            extract_with_transport(value, lambda request: called.append(request), model="fake", current_turn=2)
        self.assertEqual(called, [])

    def test_empty_prefix_rejected_before_transport(self):
        value = empty_extraction_document()
        value["data_policy"]["external_api_allowed"] = True
        called = []
        with self.assertRaises(ValidationError):
            extract_with_transport(value, lambda request: called.append(request), model="fake", current_turn=0)
        self.assertEqual(called, [])

    def test_preserve_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "result.json"
            write_new_json(path, {"original": True})
            with self.assertRaises(FileExistsError):
                write_new_json(path, {"original": False})
            self.assertEqual(json.loads(path.read_text()), {"original": True})


if __name__ == "__main__":
    unittest.main()
