"""Synthetic contract checks; these are not medical effectiveness experiments."""

from __future__ import annotations

import copy
import hashlib
import json
from itertools import product
import unittest

from interview_evidence.ledger import EvidenceLedger
from interview_evidence.models import (
    CriterionSpec, EvidenceClaim, FacetSpec, Span, Turn, ValidationError,
)
from interview_evidence.packing import canonical_payload_json, pack_evidence
from interview_evidence.planning import QuestionRecord, plan_question
from interview_evidence.reasoning import evaluate_all, evaluate_criterion


def facet(identifier="flag", scope="period-A", intent="flag-intent", question="Is the synthetic flag set?"):
    return FacetSpec(identifier, "boolean", "equals", True, scope, question, intent)


def criterion(identifier="C", facets=None):
    return CriterionSpec(identifier, "Synthetic research rule", tuple(facets or (facet(),)))


def add_evidence(ledger, rule, facet_id, value, *, identifier=None, scope=None, supersedes=(), approve=False):
    spec = next(item for item in rule.facets if item.id == facet_id)
    question_id = max(ledger.turns, default=0) + 1
    answer_id = question_id + 1
    answer = "Synthetic: 是" if value is True else "Synthetic: no" if value is False else "Synthetic: uncertain"
    ledger.add_turn(Turn(question_id, "assistant", spec.question))
    ledger.add_turn(Turn(answer_id, "user", answer, reply_to=question_id))
    claim = EvidenceClaim(
        identifier or f"E{answer_id}", rule.id, facet_id, value, scope or spec.scope_id,
        Span(question_id, 0, len(spec.question), spec.question),
        Span(answer_id, 0, len(answer), answer), tuple(supersedes),
    )
    ledger.add_claim(claim, current_turn=answer_id, approve_revision=approve)
    return claim


def states_for(criteria, statuses=None):
    # Independent immutable states from the rule engine, never fabricated model
    # status labels. Empty evidence yields unknown for every Boolean facet.
    return {rule.id: evaluate_criterion(rule, ()) for rule in criteria}


class PackingTests(unittest.TestCase):
    def test_atomic_witnesses_preserve_rule_decisions_across_compositions(self):
        # Exhaustively check the five evidence situations for three facets under
        # all, any and each admissible threshold. This protects against a packer
        # converting uncertainty/conflict into a confident aggregate judgment.
        situations = {
            "missing": (), "insufficient": (None,), "supported": (True,),
            "refuted": (False,), "conflicted": (True, False),
        }
        facets = tuple(facet(f"f{index}", intent=f"i{index}") for index in range(3))
        compositions = (("all", None), ("any", None), ("at_least", 1), ("at_least", 2), ("at_least", 3))
        for logic, threshold in compositions:
            for names in product(situations, repeat=3):
                rule = CriterionSpec("C", "Synthetic composition", facets, logic, threshold)
                ledger = EvidenceLedger((rule,))
                for spec, name in zip(facets, names):
                    for value in situations[name]:
                        add_evidence(ledger, rule, spec.id, value)
                current_turn = max(ledger.turns, default=0)
                full = evaluate_criterion(rule, ledger.active_claims(current_turn=current_turn))
                packet = pack_evidence(rule, ledger, current_turn=current_turn, budget=100000)
                retained = evaluate_criterion(rule, (ledger.claims[identifier] for identifier in packet.selected_ids))
                with self.subTest(logic=logic, threshold=threshold, names=names):
                    self.assertTrue(packet.feasible)
                    self.assertEqual(retained.status, full.status)
                    self.assertEqual(tuple(item.status for item in retained.facets), tuple(item.status for item in full.facets))
                    self.assertEqual(retained.missing_facet_ids, full.missing_facet_ids)

    def test_whole_payload_byte_budget_and_hash_boundary(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        claim = add_evidence(ledger, rule, "flag", True)
        packet = pack_evidence(rule, ledger, current_turn=2, budget=100000)
        text = canonical_payload_json(packet.payload)
        self.assertGreater(len(text.encode("utf-8")), len(text))
        self.assertEqual(packet.cost, len(text.encode("utf-8")))
        self.assertEqual(packet.input_sha256, hashlib.sha256(text.encode("utf-8")).hexdigest())
        exact = pack_evidence(rule, ledger, current_turn=2, budget=packet.cost)
        short = pack_evidence(rule, ledger, current_turn=2, budget=packet.cost - 1)
        self.assertTrue(exact.feasible)
        self.assertEqual(exact.selected_ids, (claim.id,))
        self.assertFalse(short.feasible)
        self.assertIsNone(short.payload)
        self.assertIsNone(short.input_sha256)
        self.assertEqual(short.cost, packet.cost)

    def test_conflict_required_atomically_and_all_resolved_facets_present(self):
        rule = criterion(facets=(facet("flag"), facet("other", intent="other"), facet("missing", intent="missing")))
        ledger = EvidenceLedger((rule,))
        yes = add_evidence(ledger, rule, "flag", True, identifier="yes")
        no = add_evidence(ledger, rule, "flag", False, identifier="no")
        other = add_evidence(ledger, rule, "other", True, identifier="other")
        packet = pack_evidence(rule, ledger, current_turn=6, budget=100000)
        self.assertEqual(set(packet.selected_ids), {yes.id, no.id, other.id})
        self.assertEqual(packet.payload["coverage"]["missing_facet_ids"], ["flag", "missing"])
        self.assertEqual(packet.payload["coverage"]["selected_facet_ids"], ["flag", "other"])
        values = {entry["id"]: entry["value"] for entry in packet.payload["evidence"]}
        self.assertEqual(values, {"yes": True, "no": False, "other": True})
        infeasible = pack_evidence(rule, ledger, current_turn=6, budget=packet.cost - 1)
        self.assertIsNone(infeasible.payload)
        self.assertEqual(set(infeasible.selected_ids), {"yes", "no", "other"})

    def test_latest_same_relation_witness_and_explicit_omissions(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", True, identifier="old")
        add_evidence(ledger, rule, "flag", True, identifier="latest")
        add_evidence(ledger, rule, "flag", None, identifier="uncertain")
        add_evidence(ledger, rule, "flag", False, identifier="other-period", scope="period-B")
        packet = pack_evidence(rule, ledger, current_turn=8, budget=100000)
        self.assertEqual(packet.selected_ids, ("latest",))
        self.assertEqual(packet.omitted_ids, ("old", "uncertain", "other-period"))
        self.assertTrue(packet.payload["coverage"]["selection_limited"])
        self.assertEqual(packet.payload["coverage"]["missing_facet_ids"], [])

    def test_future_revision_cannot_rewrite_historical_packet(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", True, identifier="original")
        original = pack_evidence(rule, ledger, current_turn=2, budget=100000)
        add_evidence(ledger, rule, "flag", False, identifier="correction", supersedes=("original",), approve=True)
        historical = pack_evidence(rule, ledger, current_turn=2, budget=100000)
        revised = pack_evidence(rule, ledger, current_turn=4, budget=100000)
        self.assertEqual(historical, original)
        self.assertEqual(revised.selected_ids, ("correction",))
        self.assertNotEqual(revised.input_sha256, original.input_sha256)
        self.assertEqual(historical.omitted_ids, ())

    def test_dedup_history_does_not_change_packet(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", None)
        before = pack_evidence(rule, ledger, current_turn=2, budget=100000)
        states = evaluate_all(ledger, current_turn=2)
        plan_question((rule,), states, (), current_turn=2)
        plan_question((rule,), states, (QuestionRecord("flag-intent", "period-A", 1, "answered"),), current_turn=2)
        after = pack_evidence(rule, ledger, current_turn=2, budget=100000)
        self.assertEqual(before, after)
        encoded = canonical_payload_json(after.payload)
        for forbidden in ("question_history", "clarification_count", "old_model", "dedup", '"status"'):
            self.assertNotIn(forbidden, encoded)

    def test_exact_custom_cost_uses_same_canonical_serialization(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", True)
        seen = []
        def exact_character_cost(text):
            seen.append(text)
            return len(text)
        packet = pack_evidence(rule, ledger, current_turn=2, budget=100000, cost_fn=exact_character_cost, cost_unit="unicode_codepoints")
        self.assertEqual(seen, [canonical_payload_json(packet.payload)])
        self.assertEqual(packet.cost, len(seen[0]))
        self.assertEqual(packet.cost_unit, "unicode_codepoints")

    def test_budget_and_cost_validation(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        zero = pack_evidence(rule, ledger, current_turn=0, budget=0)
        self.assertFalse(zero.feasible)
        self.assertIsNone(zero.payload)
        for kwargs in ({"budget": True}, {"budget": -1}, {"budget": 1.5}, {"budget": 20, "current_turn": True}, {"budget": 20, "cost_unit": "tokens"}, {"budget": 20, "cost_fn": lambda text: True}, {"budget": 20, "cost_fn": lambda text: -1}):
            merged = {"current_turn": 0, **kwargs}
            with self.subTest(kwargs=kwargs), self.assertRaises(ValidationError):
                pack_evidence(rule, ledger, **merged)


class PlanningTests(unittest.TestCase):
    def test_explicit_shared_intent_coverage_precedes_conflict_tie_break(self):
        first = criterion("A", (facet("f1", intent="shared"),))
        second = criterion("B", (facet("f2", intent="shared"),))
        third = criterion("C", (facet("f3", intent="conflict"),))
        ledger = EvidenceLedger((first, second, third))
        add_evidence(ledger, third, "f3", True)
        add_evidence(ledger, third, "f3", False)
        states = evaluate_all(ledger, current_turn=4)
        plan = plan_question((first, second, third), states, (), current_turn=4)
        self.assertEqual(plan.intent_id, "shared")
        self.assertEqual(plan.score, 2)
        self.assertEqual(plan.criterion_ids, ("A", "B"))
        self.assertEqual(plan.facet_ids, ("f1", "f2"))
        self.assertEqual(plan.action, "ask")

    def test_conflict_wins_equal_coverage_tie(self):
        first = criterion("A", (facet("missing", intent="missing"),))
        second = criterion("B", (facet("conflict", intent="conflict"),))
        ledger = EvidenceLedger((first, second))
        add_evidence(ledger, second, "conflict", True)
        add_evidence(ledger, second, "conflict", False)
        plan = plan_question((first, second), evaluate_all(ledger, current_turn=4), (), current_turn=4)
        self.assertEqual((plan.intent_id, plan.action), ("conflict", "clarify"))

    def test_different_event_scopes_never_deduplicate(self):
        rule = criterion(facets=(facet("old", "period-A"), facet("new", "period-B")))
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "old", True)
        states = evaluate_all(ledger, current_turn=2)
        history = (QuestionRecord("flag-intent", "period-A", 1, "answered", 2),)
        plan = plan_question((rule,), states, history, current_turn=2)
        self.assertEqual((plan.action, plan.scope_id, plan.facet_ids), ("ask", "period-B", ("new",)))

    def test_answered_insufficient_remains_unknown_and_can_clarify(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", None)
        states = evaluate_all(ledger, current_turn=2)
        history = (QuestionRecord("flag-intent", "period-A", 1, "answered"),)
        before_states, before_history = copy.deepcopy(states), copy.deepcopy(history)
        plan = plan_question((rule,), states, history, current_turn=2)
        self.assertEqual(plan.action, "clarify")
        self.assertEqual(states["C"].status, "unknown")
        self.assertEqual(states, before_states)
        self.assertEqual(history, before_history)

    def test_clarification_limit_cannot_be_reset_by_later_lower_count(self):
        rule = criterion()
        history = (
            QuestionRecord("flag-intent", "period-A", 1, "answered", 2),
            QuestionRecord("flag-intent", "period-A", 3, "asked", 0),
        )
        plan = plan_question((rule,), states_for((rule,)), history, current_turn=3, max_clarifications=2)
        self.assertEqual(plan.action, "defer")
        self.assertIsNone(plan.question)
        self.assertIn("limit", plan.reason)

    def test_declined_group_defers_and_unasked_alternative_remains_eligible(self):
        rule = criterion(facets=(facet("declined", intent="declined"), facet("new", intent="new")))
        history = (QuestionRecord("declined", "period-A", 1, "declined"),)
        plan = plan_question((rule,), states_for((rule,)), history, current_turn=1)
        self.assertEqual((plan.action, plan.intent_id), ("ask", "new"))
        all_declined = history + (QuestionRecord("new", "period-A", 1, "declined"),)
        plan = plan_question((rule,), states_for((rule,)), all_declined, current_turn=1)
        self.assertEqual((plan.action, plan.intent_id, plan.question), ("defer", "declined", None))

    def test_zero_clarifications_still_allows_initial_question(self):
        rule = criterion()
        states = states_for((rule,))
        self.assertEqual(plan_question((rule,), states, (), current_turn=0, max_clarifications=0).action, "ask")
        history = (QuestionRecord("flag-intent", "period-A", 1, "asked"),)
        self.assertEqual(plan_question((rule,), states, history, current_turn=1, max_clarifications=0).action, "defer")

    def test_no_unresolved_facets_returns_none(self):
        rule = criterion()
        ledger = EvidenceLedger((rule,))
        add_evidence(ledger, rule, "flag", False)
        plan = plan_question((rule,), evaluate_all(ledger, current_turn=2), (), current_turn=2)
        self.assertEqual((plan.action, plan.score, plan.question), ("none", 0, None))

    def test_future_history_and_bad_limits_rejected(self):
        rule = criterion()
        states = states_for((rule,))
        history = (QuestionRecord("flag-intent", "period-A", 3, "asked"),)
        with self.assertRaises(ValidationError):
            plan_question((rule,), states, history, current_turn=2)
        for bad in (-1, True, 1.5):
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                plan_question((rule,), states, (), current_turn=0, max_clarifications=bad)
        with self.assertRaises(ValidationError):
            plan_question((rule,), {}, (), current_turn=0)

    def test_question_record_strict_validation(self):
        for args in (("", "scope", 1, "asked"), ("i", "s", 0, "asked"), ("i", "s", True, "asked"), ("i", "s", 1, "satisfied"), ("i", "s", 1, []), ("i", "s", 1, "asked", -1)):
            with self.subTest(args=args), self.assertRaises(ValidationError):
                QuestionRecord(*args)


if __name__ == "__main__":
    unittest.main()
